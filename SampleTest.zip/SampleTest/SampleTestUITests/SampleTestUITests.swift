//
//  SampleTestUITests.swift
//  SampleTestUITests
//
//  Created by Le Thi Van Anh on 3/28/20.
//  Copyright © 2020 Le Thi Van Anh. All rights reserved.
//

import XCTest

class SampleTestUITests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample1() {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        
        //Add arguments for "Test Case name" label and "Actual result" label
        app.launchArguments.append("Your test case")
        app.launchArguments.append("Your actual result")
        app.launch()

        //Waiting for pressing Pass/Fail button with 30s timeout
        let blankLabel = app.staticTexts["blankLabel"]
        _ = blankLabel.waitForExistence(timeout: 30)
    
        //Get the selected button (Pass/Fail)
        let selectedButtonLabel = app.staticTexts["selectedButtonLabel"]
        XCTAssertEqual(selectedButtonLabel.label, "pass")
        
    }
    
    func testExample2() {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        
        //Add arguments for "Test Case name" label and "Actual result" label
        app.launchArguments.append("2 + 2")
        app.launchArguments.append("4")
        app.launch()

        //Waiting for pressing Pass/Fail button with 30s timeout
        let blankLabel = app.staticTexts["blankLabel"]
        _ = blankLabel.waitForExistence(timeout: 30)
    
        //Get the selected button (Pass/Fail)
        let selectedButtonLabel = app.staticTexts["selectedButtonLabel"]
        XCTAssertEqual(selectedButtonLabel.label, "pass")
        
    }
}
