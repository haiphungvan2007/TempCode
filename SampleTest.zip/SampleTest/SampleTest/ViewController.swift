//
//  ViewController.swift
//  SampleTest
//
//  Created by Le Thi Van Anh on 3/28/20.
//  Copyright © 2020 Le Thi Van Anh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var testCaseLabel: UILabel!
    @IBOutlet weak var selectedButtonLabel: UILabel!
    @IBOutlet weak var blankLabel: UILabel!
    @IBOutlet weak var actualResultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let arguments = ProcessInfo.processInfo.arguments;
        if (arguments.count > 2) {
            testCaseLabel.text = "Test Case: " + arguments[1]
            actualResultLabel.text = "Actual Result: " + arguments[2]
        }
        // Do any additional setup after loading the view.
    }


    @IBAction func onPassButtonTouched(_
        sender: Any) {
        selectedButtonLabel.text = "pass"
        blankLabel.isHidden = false
    }
    
    
    @IBAction func onFailButtonTouched(_ sender: Any) {
        selectedButtonLabel.text = "fail"
        blankLabel.isHidden = false
    }
}

