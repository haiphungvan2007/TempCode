from bs4 import BeautifulSoup
import re
import json

ANSWER_FILE_NAME = 'ScrumAnswers.json'
HTML_FILE = 'OpenScrum.html'

g_answerDataBase = {}

#Open existed answer file
with open(ANSWER_FILE_NAME) as json_file:
    g_answerDataBase = json.load(json_file)
    

with open(HTML_FILE, 'r', encoding="utf8") as f:
    contents = f.read()
    htmlDocument = BeautifulSoup(contents, 'html.parser')
    divContainerList = htmlDocument.find_all('div', class_='qd')
    
    for divContainer in divContainerList:        
        #Get question
        questionText = ""
        questionDivList = divContainer.find_all('div', class_='qsholder')        
        if len(questionDivList) > 0:           
            questionText = questionDivList[0].text
            #Remove [b] tag from question            
            questionText = re.sub("\[\s*b[^>]*\](.*?)\[\s*/\s*b\]", "", questionText)
            
            #Remove [strong] tag from question
            questionText = re.sub("\[\s*strong[^>]*\](.*?)\[\s*/\s*strong\]", "", questionText)
            
            #Remove [i] tag from question
            questionText = re.sub("\[\s*i[^>]*\](.*?)\[\s*/\s*i\]", "", questionText)
            
            #Remove \r \n and trim text
            questionText = questionText.strip().replace("\r", "").replace("\n", "");
            print(questionText)
        
        #Get answer 
        answerList = []
        answerContaineList = divContainer.find_all('div', class_='sarow')
        for answerContainer in answerContaineList:
            #Check answer div has tick image or not
            tickDivList = answerContainer.find_all('div', class_='satick');
            imgDivList = tickDivList[0].find_all('img')
            if (len(tickDivList) > 0) and len(imgDivList) > 0:            
                 #If DIV has tick, get the answer
                if ("arrow_bluev" in imgDivList[0]['src']) or ("correct" in imgDivList[0]['src']): 
                    answerDivList = answerContainer.find_all('div', class_='saans')
                    if len(answerDivList) > 0:
                        answerText = answerDivList[0].text
                        answerText = answerText.replace("\n", "")
                        answerText = answerText.replace("\r", "")
                        answerText = answerText.strip()
                        if len(answerText) > 0:
                            answerList.append(answerText);
        
        if len(questionText) > 0 and len(answerList) > 0:
            g_answerDataBase[questionText] = answerList

#Save answer to JSON file
with open(ANSWER_FILE_NAME, 'w') as outfile:
    json.dump(g_answerDataBase, outfile)
            
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        