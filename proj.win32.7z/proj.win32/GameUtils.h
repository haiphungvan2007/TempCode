#ifndef __GAME_UTILS_H______
#define __GAME_UTILS_H______

#include "GameD"
class GameUtils
{
public:
	static cocos2d::Color3B getColorByType(TetriminoType inputType);
};
#endif

