#ifndef __CELL_SPRITE_H__
#define __CELL_SPRITE_H__

#include "cocos2d.h"

using namespace cocos2d;

class CellSprite : public CCNode
{
public:
	virtual bool init();
	static CellSprite* createCellWith(float width, float height, );
};

#endif 

