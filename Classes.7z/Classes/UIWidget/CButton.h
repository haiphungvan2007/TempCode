#ifndef __CBUTTON_H____
#define __CBUTTON_H____

#include <string>
#include "cocos2d.h"
#include "../Commons/GameDefine.h"
#include "ui/CocosGUI.h"

class CButton : public cocos2d::ui::Widget
{
private:
	cocos2d::LayerColor*	m_colorNode0;
	cocos2d::LayerColor*	m_colorNode1;
	cocos2d::Label*			m_label;
	
	
	

public:
	virtual bool init();
	CREATE_FUNC(CButton);	
	void setOpacity(GLubyte opacity) override;

	std::string			m_title = "";
	std::string			m_fontName = "Arial";
	float				m_fontSize = 16.0f;
	cocos2d::Color4B	m_textColor = cocos2d::Color4B::BLACK;


	float				m_borderSize = 1.0f;
	float				m_padding = 5.0f;
	cocos2d::Color4B	m_borderColor = cocos2d::Color4B::BLACK;
	cocos2d::Color4B	m_backgroundColor = cocos2d::Color4B::WHITE;
	void updateButtonLayout();

};

#endif
