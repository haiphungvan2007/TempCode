#include "CButton.h"
#include "../Commons/GameUtils.h"

bool CButton::init() {
	//////////////////////////////
	// 1. super init first
	if (!cocos2d::ui::Widget::init())
	{
		return false;
	}

	this->m_colorNode0 = cocos2d::LayerColor::create(cocos2d::Color4B(this->m_borderColor));
	this->addChild(this->m_colorNode0);

	this->m_colorNode1 = cocos2d::LayerColor::create(cocos2d::Color4B(this->m_backgroundColor));
	this->addChild(this->m_colorNode1);


	this->m_label = cocos2d::Label::createWithSystemFont(this->m_title, this->m_fontName, this->m_fontSize);
	this->addChild(this->m_label);

	return true;
}



void CButton::setOpacity(GLubyte opacity) {
	this->m_colorNode0->setOpacity(opacity);
	this->m_colorNode1->setOpacity(opacity);
	this->m_label->setOpacity(opacity);
}


void CButton::updateButtonLayout() {
	
	this->m_label->setSystemFontName(this->m_fontName);
	this->m_label->setSystemFontSize(this->m_fontSize);
	this->m_label->setString(this->m_title);
	this->m_label->setTextColor(this->m_textColor);
	this->m_label->setAnchorPoint(cocos2d::Vec2(0, 0));
	this->m_label->setPositionX(this->m_borderSize + this->m_padding);
	this->m_label->setPositionY(this->m_borderSize + this->m_padding);	
	
	float buttonWidth = this->m_label->getContentSize().width + this->m_borderSize * 2.0f + this->m_padding * 2.0f;
	float buttonHeigh = this->m_label->getContentSize().height + this->m_borderSize * 2.0f + this->m_padding * 2.0f;
	this->m_colorNode0->initWithColor(this->m_borderColor);
	this->m_colorNode0->setContentSize(cocos2d::Size(buttonWidth, buttonHeigh));	
	this->m_colorNode0->setAnchorPoint(cocos2d::Vec2(0, 0));
	this->setContentSize(cocos2d::Size(buttonWidth, buttonHeigh));


	float tempWidth = this->m_label->getContentSize().width + this->m_padding * 2.0;
	float tempHeigh = this->m_label->getContentSize().height + this->m_padding * 2.0;
	this->m_colorNode1->initWithColor(this->m_backgroundColor);
	this->m_colorNode1->setContentSize(cocos2d::Size(tempWidth, tempHeigh));
	this->m_colorNode1->setAnchorPoint(cocos2d::Vec2(0, 0));
	this->m_colorNode1->setPositionX(this->m_borderSize);
	this->m_colorNode1->setPositionY(this->m_borderSize);	
}
