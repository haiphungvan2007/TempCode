#include "GameUtils.h"


bool GameUtils::isEmptyTetriminoType(TetriminoType inputType) {
	if ((inputType == TetriminoType::EMPTY) || 
		(inputType == TetriminoType::HINT)	||	
		(inputType == TetriminoType::HINT_SPELL)){
		return true;
	}
	return false;
}

bool GameUtils::isObstackTetriminoType(TetriminoType inputType) {
	if ((inputType == TetriminoType::NORMAL) ||
		(inputType == TetriminoType::ROCK) ||
		(inputType == TetriminoType::NORMAL_SPELL)){
		return true;
	}
	return false;
}

bool GameUtils::isHintTetriminoType(TetriminoType inputType) {
	if ((inputType == TetriminoType::HINT) ||
		(inputType == TetriminoType::HINT_SPELL)){
		return true;
	}
	return false;

}

bool GameUtils::isMovableTetriminoType(TetriminoType inputType) {
	if (inputType > TetriminoType::NORMAL_SPELL) {
		return true;
	}
	return false;

}

std::vector<std::vector<TetriminoType>> GameUtils::getTetriminoTemplate(TetriminoShape inputShape) {
	std::vector<std::vector<TetriminoType>> emptyVector;
	if (inputShape == TetriminoShape::I) {
		return {	
			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::NORMAL }
		};

	}
	else if (inputShape == TetriminoShape::J) {

		return {
			{ TetriminoType::NORMAL, TetriminoType::EMPTY, TetriminoType::EMPTY},

			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::NORMAL}
		};

	}
	else if (inputShape == TetriminoShape::L) {
		return {
			{ TetriminoType::EMPTY, TetriminoType::EMPTY, TetriminoType::NORMAL },

			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::NORMAL }
		};

	}
	else if (inputShape == TetriminoShape::O) {

		return{

			{ TetriminoType::NORMAL, TetriminoType::NORMAL },

			{ TetriminoType::NORMAL, TetriminoType::NORMAL }

		};

	}
	else if (inputShape == TetriminoShape::S) {

		return {
			{ TetriminoType::EMPTY, TetriminoType::NORMAL, TetriminoType::NORMAL },

			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::EMPTY }
		};

	}
	else if (inputShape == TetriminoShape::T) {

		return {
			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::NORMAL },

			{ TetriminoType::EMPTY, TetriminoType::NORMAL, TetriminoType::EMPTY }
		};

	}
	else if (inputShape == TetriminoShape::Z) {

		return{

			{ TetriminoType::NORMAL, TetriminoType::NORMAL, TetriminoType::EMPTY },

			{ TetriminoType::EMPTY, TetriminoType::NORMAL, TetriminoType::NORMAL }
		};

	}
	return emptyVector;
}