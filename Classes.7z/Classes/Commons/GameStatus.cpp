#include "GameStatus.h"
#include "GameUtils.h"
#include <stdlib.h>
#include <algorithm>

GameStatus* GameStatus::m_instance = NULL;

GameStatus::GameStatus() {

}

GameStatus::~GameStatus() {

}

GameStatus* GameStatus::getInstance() {
	if (m_instance == NULL) {
		m_instance = new GameStatus();

		for (int i = 0; i < NEXT_QUEU_SIZE; i++) {
			m_instance->randomTetri();
		}		
	}
	return m_instance;
}

void GameStatus::setIsHostGame(bool bValue) {
	this->m_IsHostGame = bValue;
}
bool GameStatus::getIsHostGame() {
	return this->m_IsHostGame;
}

void GameStatus::setIsGamePaused(bool bValue) {
	this->m_IsGamePaused = bValue;
}

bool GameStatus::getIsGamePaused() {
	return this->m_IsGamePaused;
}

void GameStatus::setGameSpeed(int32_t newValue) {
	this->m_GameSpeed = newValue;
	if (newValue > MAX_GAME_LEVEL) {
		this->m_GameSpeed = MAX_GAME_LEVEL;
	}
	this->m_TimeDelay = MAX_TIME_DELAY - (float)(this->m_GameSpeed - 1) * TIME_DELAY_STEP;
}

int32_t GameStatus::getGameSpeed() {
	return this->m_GameSpeed;
}

void GameStatus::setTimeDelay(float newValue) {
	this->m_TimeDelay = newValue;
}
float GameStatus::getTimeDelay() {
	return this->m_TimeDelay;
}

void GameStatus::setTurnCount(int32_t newValue) {
	this->m_TurnCount = newValue;
	if (newValue > TURN_COUT_PER_LEVEL) {
		this->m_TurnCount = 0;
		this->setGameSpeed(m_GameSpeed + 1);		
	}
}

int32_t GameStatus::getTurnCount() {
	return this->m_TurnCount;
}

std::vector<std::vector<std::vector<TetriminoType>>> GameStatus::getNext1() {
	std::vector<std::vector<std::vector<TetriminoType>>> retVal;
	retVal.push_back(this->m_nextQueu.front());
	this->m_nextQueu.pop();
	this->randomTetri();

	std::vector<std::vector<std::vector<TetriminoType>>> next2 = this->getNext2();
	retVal.push_back(next2[0]);
	retVal.push_back(next2[1]);

	return retVal;
}

std::vector<std::vector<std::vector<TetriminoType>>> GameStatus::getNext2() {
	std::vector<std::vector<std::vector<TetriminoType>>> retVal;

	std::queue<std::vector<std::vector<TetriminoType>>> tempQueu = std::queue<std::vector<std::vector<TetriminoType>>>(this->m_nextQueu);
	for (int i = 0; i < NEXT_IN_VIEW; i++) {
		std::vector<std::vector<TetriminoType>> tempTetris = tempQueu.front();
		tempQueu.pop();
		retVal.push_back(tempTetris);
	}
	return retVal;
}

void GameStatus::randomTetri() {		
	this->m_SpellCount++;
	TetriminoShape randomShape = static_cast<TetriminoShape>(rand() % (TetriminoShape::Z + 1));
	std::vector<std::vector<TetriminoType>> tempTetris = GameUtils::getTetriminoTemplate(randomShape);

	TetriminoType randomColor = static_cast<TetriminoType>(rand() % 7 + TetriminoType::BLUE);
	std::vector<std::vector<int64_t>> pixelList;
	for (int64_t i = 0; i < tempTetris.size(); i++) {
		for (int64_t j = 0; j < tempTetris[0].size(); j++) {
			if (tempTetris[i][j] == TetriminoType::NORMAL) {
				tempTetris[i][j] = randomColor;
				pixelList.push_back({i, j});
			}
		}
	}
	
	//If it's a spell tetris
	if ((this->m_SpellCount > this->m_spellDuration) &&
		(this->m_spellDuration > 0)) {
		m_SpellCount = 0;
		int64_t randomIndex = rand() % pixelList.size();
		int64_t row = pixelList[randomIndex][0];
		int64_t col = pixelList[randomIndex][1];
		tempTetris[row][col] = TetriminoType::SPELL;
	}
	this->m_nextQueu.push(tempTetris);
}

void GameStatus::setSpellDuration(int32_t newValue) {
	this->m_spellDuration = newValue;
}