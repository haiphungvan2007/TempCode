#ifndef __GAME_DEFINE_H___
#define __GAME_DEFINE_H___

#include "cocos2d.h"
#include <map>

#define T_BORDER_WIDTH 1.0f
#define TETRIS_BOARD_COLUMN 10
#define TETRIS_BOARD_ROW 27
#define TETRIS_ADDITON_ROW 5

#define MAX_GAME_LEVEL 10
#define MAX_TIME_DELAY 1.0f
#define TIME_DELAY_STEP 0.1f
#define TURN_COUT_PER_LEVEL 2
#define BIG_SCORE 4
#define MAX_EMPTY_IN_ROW 4

#define NEXT_QUEU_SIZE 6
#define NEXT_IN_VIEW 2

#define BLIND_MAX_TURN 3
#define GRAVITY_MAX_TURN 3

#define MAX_SPELL_COUNT 4


#define IMAGE_TILE_SIZE 18.0f
#define IMAGE_TILE_FILE "tiles.png"

#define IMAGE_BOARD_FILE "board.png"
#define IMAGE_SPELL_FILE "spell.png"
#define IMAGE_ROCK_FILE "rock.png"


#define GAME_SOUND_DEATH "/sounds/death.wav"
#define GAME_SOUND_DOWN "/sounds/down.wav"
#define GAME_SOUND_HIT "/sounds/hit.wav"
#define GAME_SOUND_LEVEL_UP "/sounds/level_up.wav"
#define GAME_SOUND_PAUSE "/sounds/pause.wav"
#define GAME_SOUND_ROTATE "/sounds/rotate.wav"
#define GAME_SOUND_SCORE "/sounds/score.wav"
#define GAME_SOUND_SCORE1 "/sounds/score1.wav"
#define GAME_SOUND_THEME "/sounds/theme.mp3"
#define GAME_SOUND_WIN "/sounds/win.wav"


#define GAME_SERVER_URL "ws://127.0.0.1:3000"

enum TetriminoShape {
	I = 0,
	J,
	L,
	O,
	S,
	T,
	Z

};

enum TetriminoType {
	EMPTY = 0,	
	HINT,
	HINT_SPELL,
	NORMAL,
	NORMAL_SPELL,
	SPELL,
	ROCK,
	BLUE,
	PURPLE,
	RED,
	GREEN,
	YELLOW,
	LIGHT_BLUE,
	ORANGE
};

const cocos2d::Color3B CYAN_COLOR = cocos2d::Color3B(0, 255, 255);
const cocos2d::Color3B BLUE_COLOR = cocos2d::Color3B(0, 0, 255);
const cocos2d::Color3B ORANGE_COLOR = cocos2d::Color3B(255, 165, 0);
const cocos2d::Color3B YELLOW_COLOR = cocos2d::Color3B(255, 255, 0);
const cocos2d::Color3B GREEN_COLOR = cocos2d::Color3B(0, 128, 0);
const cocos2d::Color3B PURPLE_COLOR = cocos2d::Color3B(128, 0, 128);
const cocos2d::Color3B RED_COLOR = cocos2d::Color3B(255, 0, 0);
const cocos2d::Color3B RED_ZONE_COLOR = cocos2d::Color3B(255, 255, 0);
const cocos2d::Color3B BLACK_ZONE_COLOR = cocos2d::Color3B(0, 0, 0);
const cocos2d::Color3B HINT_COLOR = cocos2d::Color3B(255, 192, 203);
const cocos2d::Color3B EMPTY_COLOR = cocos2d::Color3B(255, 255, 255);
const cocos2d::Color3B BORDER_COLOR = cocos2d::Color3B(0, 0, 0);
const cocos2d::Color3B SPELL_COLOR = cocos2d::Color3B(0, 0, 0);
const cocos2d::Color3B NORMAL_COLOR = cocos2d::Color3B(128, 128, 128);
const cocos2d::Color3B ROCK_COLOR = cocos2d::Color3B(0, 0, 255);
#endif