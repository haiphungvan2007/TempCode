#ifndef ___GAME_STATUS_H___
#define ___GAME_STATUS_H___

#include "GameDefine.h"

class GameStatus
{
private:
	static GameStatus* m_instance;
	bool m_IsHostGame = false;
	bool m_IsGamePaused = false;
	
	int32_t m_GameSpeed = 1;
	int32_t m_TurnCount = 0;
	int32_t m_SpellCount = 0;
	int32_t m_spellDuration = 6;
	float m_TimeDelay = MAX_TIME_DELAY;
	std::queue<std::vector<std::vector<TetriminoType>>> m_nextQueu;	

	GameStatus();
	~GameStatus();
	void randomTetri();
public:	
	bool m_IsDeath = false;
	int m_GravityTurn = 0;
	int m_BlindTurn = 0;
	int m_NumberOfSpell = 0;

	static GameStatus* getInstance();
	
	void setIsHostGame(bool bValue);
	bool getIsHostGame();

	void setIsGamePaused(bool bValue);
	bool getIsGamePaused();

	void setGameSpeed(int32_t newValue);
	int32_t getGameSpeed();

	void setTimeDelay(float newValue);
	float getTimeDelay();

	void setTurnCount(int32_t newValue);
	int32_t getTurnCount();

	std::vector<std::vector<std::vector<TetriminoType>>> getNext1();
	std::vector<std::vector<std::vector<TetriminoType>>> getNext2();	

	void setSpellDuration(int32_t newValue);
};

#endif