#ifndef ___GAME_UTILS_H___
#define ___GAME_UTILS_H___

#include "GameDefine.h"

class GameUtils
{
public:	
	static bool isEmptyTetriminoType(TetriminoType inputType);
	static bool isObstackTetriminoType(TetriminoType inputType);
	static bool isHintTetriminoType(TetriminoType inputType);
	static bool isMovableTetriminoType(TetriminoType inputType);
	static std::vector<std::vector<TetriminoType>> getTetriminoTemplate(TetriminoShape inputShape);
};

#endif