#ifndef __LoginScene_H__
#define __LoginScene_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "../Sprites/TetriBoard.h"
#include "../Sprites/NextBoard.h"
#include "../Sprites/SpellBarSprite.h"
#include "../Network/GameService.h"
#include "ui/CocosGUI.h"

class LoginScene : public cocos2d::Scene, public GameClientInterface
{
private:
	LoginScene();
	
public:
    static cocos2d::Scene* createScene();
    virtual bool init();
	
	cocos2d::Label* m_label;
	cocos2d::ui::TextField* m_textField;
	
    // implement the "static create()" mthod manually
	CREATE_FUNC(LoginScene);

	virtual void onConnect(cocos2d::network::WebSocket* client) override;
	virtual void onDisconnect(cocos2d::network::WebSocket* client) override;
	virtual void onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) override;
};

#endif // __LoginScene_H__
