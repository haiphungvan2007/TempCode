#ifndef __BaseScene_H__
#define __BaseScene_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "../Sprites/TetriBoard.h"
#include "../Sprites/NextBoard.h"
#include "../Sprites/SpellBarSprite.h"
#include "../Network/GameService.h"
#include "ui/CocosGUI.h"

class BaseScene : public cocos2d::Scene
{
private:
	BaseScene();
	
public:  
    virtual bool init();	
	CREATE_FUNC(BaseScene);

};

#endif // __BaseScene_H__
