#ifndef __GAME_SCENE_H__
#define __GAME_SCENE_H__

#include "cocos2d.h"
#include "../Sprites/TetriBoard.h"
#include "../Sprites/NextBoard.h"
#include "../Sprites/SpellBarSprite.h"
#include "../Network/GameService.h"

class GameScene : public cocos2d::Scene, public GameClientInterface
{
private:
	TetriBoard* m_gameBoard = nullptr;
	NextBoard* m_nextBoard = nullptr;
	SpellBarSprite* m_spellBar = nullptr;
	
	GameScene();
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
	void onKeyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event);
	void onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event);

   
	NextBoard* getNextBoard();
	SpellBarSprite* getSpellBar();
    // implement the "static create()" method manually
	CREATE_FUNC(GameScene);

	virtual void onConnect(cocos2d::network::WebSocket* client) override;
	virtual void onDisconnect(cocos2d::network::WebSocket* client) override;
	virtual void onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) override;
};

#endif // __GAME_SCENE_H__
