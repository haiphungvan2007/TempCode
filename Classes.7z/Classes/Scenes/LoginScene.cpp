#include "LoginScene.h"
#include "SimpleAudioEngine.h"
#include "../Sprites/PixelSprite.h"
#include "../Sprites/TetriSprite.h"
#include "../UIWidget/CButton.h"
#include "../Commons/GameUtils.h"
#include "../Commons/GameStatus.h"
#include "../Network/GameService.h"

USING_NS_CC;


LoginScene::LoginScene():
	GameClientInterface("LoginScene"){
}


Scene* LoginScene::createScene()
{
	return LoginScene::create();
}


// on "init" you need to initialize your instance
bool LoginScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }
	

	Director::getInstance()->getOpenGLView()->setIMEKeyboardState(true);
	// Default is landscape orientation
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 screenOrigin = Director::getInstance()->getVisibleOrigin();

	Director::getInstance()->setClearColor(cocos2d::Color4F(0, 0, 0, 1.0));

	float screenWidth = visibleSize.width;
	float screenHeight = visibleSize.height;

	cocos2d::Node* containerView = cocos2d::Node::create();

	this->m_textField = cocos2d::ui::TextField::create("User name", "Arial", 16);
	this->m_textField->setCursorChar('|');
	this->m_textField->setCursorEnabled(true);
	this->m_textField->setTextHorizontalAlignment(TextHAlignment::LEFT);
	this->m_textField->setAnchorPoint(cocos2d::Vec2(0, 0.5));
	this->m_textField->setTextColor(Color4B::WHITE);	
	this->m_textField->setMaxLength(20);
	this->m_textField->setMaxLengthEnabled(true);	
	this->m_textField->setTextAreaSize(m_textField->getContentSize());
	this->m_textField->setTouchAreaEnabled(true);
	this->m_textField->setTouchSize(m_textField->getContentSize());
	containerView->addChild(this->m_textField);

	//Begin Create button
	CButton* cButton = CButton::create();
	cButton->m_title = "Create";
	cButton->setAnchorPoint(cocos2d::Vec2(0, 0.5));
	cButton->setPositionX(this->m_textField->getContentSize().width + 5.0f);
	cButton->updateButtonLayout();
	cButton->setTouchEnabled(true);
	cButton->addTouchEventListener([&](Ref* sender, cocos2d::ui::Widget::TouchEventType type){
		switch (type)
		{
		case cocos2d::ui::Widget::TouchEventType::BEGAN:
			break;
		case cocos2d::ui::Widget::TouchEventType::ENDED:
			CCLOG(">>>>>>>>>>>>>>>>>>>>>> %s", this->m_textField->getString().c_str());
			break;
		default:
			break;
		}
	});
	
	containerView->addChild(cButton);	
	//End Create button	


	float containerWidth = this->m_textField->getContentSize().width + 5.0f + cButton->getContentSize().width;
	float containerHeight = 0;	
	if (cButton->getContentSize().height > this->m_textField->getContentSize().height) {
		containerHeight = cButton->getContentSize().height;
	}
	else {
		containerHeight = this->m_textField->getContentSize().height;
	}

	this->m_textField->setPositionY(containerHeight*0.5f);
	cButton->setPositionY(containerHeight*0.5f);

	containerView->setContentSize(cocos2d::Size(containerWidth, containerHeight));
	containerView->setAnchorPoint(cocos2d::Vec2(0.5f, 0.5f));
	containerView->setPosition(cocos2d::Vec2(screenWidth * 0.5f, screenHeight * 0.5f));

	this->addChild(containerView);

	//Init network
	GameService::getInstance()->registerGameClient(this);

    return true;
}

// Implement network API
void LoginScene::onConnect(cocos2d::network::WebSocket* client) {
	
}

void LoginScene::onDisconnect(cocos2d::network::WebSocket* client) {

}

void LoginScene::onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) {

}