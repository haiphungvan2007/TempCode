#include "GameScene.h"
#include "SimpleAudioEngine.h"
#include "../Sprites/PixelSprite.h"
#include "../Sprites/TetriSprite.h"
#include "../Commons/GameUtils.h"
#include "../Commons/GameStatus.h"
#include "../Network/GameService.h"

USING_NS_CC;

Scene* GameScene::createScene()
{
	return GameScene::create();
}

GameScene::GameScene():
	GameClientInterface("GameScene"){
}

// on "init" you need to initialize your instance
bool GameScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }


	// Default is landscape orientation
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 screenOrigin = Director::getInstance()->getVisibleOrigin();

	float screenWidth = visibleSize.width;
	float screenHeight = visibleSize.height;

	//Calculate board game size and position
	float boardHeight = screenHeight * 0.8f;
	float boardWidth = boardHeight * (float)(TETRIS_BOARD_COLUMN) / (float)(TETRIS_BOARD_ROW);
	float boardX = screenOrigin.x + (screenWidth - boardWidth) / 2.0f;
	float boardY = screenOrigin.y + (screenHeight - boardHeight) / 2.0f;

	float pixcelSize = boardWidth / (float)TETRIS_BOARD_COLUMN;


	

	//Init for game board
	this->m_gameBoard = TetriBoard::create();
	this->m_gameBoard->updateBoardSize(boardWidth, boardHeight);
	this->m_gameBoard->setPosition(cocos2d::Vec2(boardX, boardY));
	this->m_gameBoard->setParentScene(this);
	this->addChild(this->m_gameBoard);

	
	//Init for next board
	this->m_nextBoard = NextBoard::create();
	this->m_nextBoard->updatePixcelSize(pixcelSize, pixcelSize);
	this->m_nextBoard->setPosition(cocos2d::Vec2(100, 100));
	this->addChild(this->m_nextBoard);
	
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GameScene::onKeyPressed, this);
	listener->onKeyReleased = CC_CALLBACK_2(GameScene::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);


	auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
	audio->preloadBackgroundMusic(GAME_SOUND_THEME);
	audio->playBackgroundMusic(GAME_SOUND_THEME, true);

	this->m_gameBoard->onTurn = []() {
		auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
		audio->preloadEffect(GAME_SOUND_ROTATE);
		audio->playEffect(GAME_SOUND_ROTATE);
	};

	this->m_gameBoard->onDeath = []() {
		auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
		audio->stopBackgroundMusic(true);
		audio->preloadEffect(GAME_SOUND_DEATH);
		audio->playEffect(GAME_SOUND_DEATH);
	};

	this->m_gameBoard->onMoveDown = []() {
		auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
		audio->preloadEffect(GAME_SOUND_DOWN);
		audio->playEffect(GAME_SOUND_DOWN);
	};

	this->m_gameBoard->onScoring = [](bool isBigScore) {
		auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
		if (isBigScore) {
			audio->preloadEffect(GAME_SOUND_SCORE1);
			audio->playEffect(GAME_SOUND_SCORE1);
		}
		else {
			audio->preloadEffect(GAME_SOUND_SCORE);
			audio->playEffect(GAME_SOUND_SCORE);
		}
		
	};
	this->m_gameBoard->getNextTetrimino();

	//Init spell bar
	this->m_spellBar = SpellBarSprite::create();
	this->m_spellBar->updatePixcelSize(pixcelSize, pixcelSize);
	this->m_spellBar->refreshBar();
	this->m_spellBar->setAnchorPoint(cocos2d::Vec2(0, 0));
	this->m_spellBar->setPosition(cocos2d::Vec2(boardX + boardWidth + 10.0f, boardY));
	this->addChild(this->m_spellBar);

	//Init network
	GameService::getInstance()->registerGameClient(this);

    return true;
}

void GameScene::onKeyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event) {
	if (keyCode == cocos2d::EventKeyboard::KeyCode::KEY_UP_ARROW) {		
		this->m_gameBoard->turnTetrimino();
		
	}
	else if (keyCode == cocos2d::EventKeyboard::KeyCode::KEY_LEFT_ARROW) {		
		this->m_gameBoard->moveTetriminoHorizontal(-1);
	}
	else if (keyCode == cocos2d::EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {		
		this->m_gameBoard->moveTetriminoHorizontal(1);
	}
	else if (keyCode == cocos2d::EventKeyboard::KeyCode::KEY_DOWN_ARROW) {
		this->m_gameBoard->moveTetriminoDown(true);
	}
	else if (keyCode == cocos2d::EventKeyboard::KeyCode::KEY_SPACE) {
		this->m_gameBoard->setBlindMode();
	}
	
}

void GameScene::onKeyReleased(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event) {
}


NextBoard* GameScene::getNextBoard() {
	return this->m_nextBoard;
}

SpellBarSprite* GameScene::getSpellBar() {
	return this->m_spellBar;
}


// Implement network API
void GameScene::onConnect(cocos2d::network::WebSocket* client) {
	
}

void GameScene::onDisconnect(cocos2d::network::WebSocket* client) {

}

void GameScene::onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) {

}