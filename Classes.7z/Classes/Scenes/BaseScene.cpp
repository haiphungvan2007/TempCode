#include "BaseScene.h"
#include "SimpleAudioEngine.h"
#include "../Sprites/PixelSprite.h"
#include "../Sprites/TetriSprite.h"
#include "../UIWidget/CButton.h"
#include "../Commons/GameUtils.h"
#include "../Commons/GameStatus.h"
#include "../Network/GameService.h"

USING_NS_CC;


BaseScene::BaseScene() {
}

// on "init" you need to initialize your instance
bool BaseScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }
    return true;
}