#include "GameService.h"
#include "../Commons/GameDefine.h"


GameClientInterface::GameClientInterface() {
}


GameClientInterface::GameClientInterface(std::string clientName) {
	this->m_clientName = clientName;
}

std::string GameClientInterface::getClientName() {
	return this->m_clientName;
}

bool GameClientInterface::getIsClientReleased() {
	return this->m_isClientReleased;
}

void GameClientInterface::onConnect(cocos2d::network::WebSocket* client) {

}
void GameClientInterface::onDisconnect(cocos2d::network::WebSocket* client) {

}

void GameClientInterface::onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) {

}

void GameClientInterface::onLogin(bool isSucees, std::string responseMessage) {

}


GameService* GameService::m_instance = NULL;

GameService::GameService() {
	
	this->m_gameSocket = new cocos2d::network::WebSocket();

	//register event callbacks using the CC_CALLBACK_2() macro and passing the instance of the target class
	this->m_gameSocket->init(*this, GAME_SERVER_URL);
}

GameService::~GameService() {
	if (this->m_gameSocket) {
		this->m_gameSocket->close();
		delete this->m_gameSocket;
		this->m_gameSocket = NULL;
	}
	
	
}

GameService* GameService::getInstance() {
	if (m_instance == NULL) {
		m_instance = new GameService();
	}
	return m_instance;
}

void GameService::registerGameClient(GameClientInterface* gameClient) {
	if (gameClient && (this->m_observerMap.count(gameClient->getClientName()) == 0) && (!gameClient->getIsClientReleased())) {
		this->m_observerMap[gameClient->getClientName()] = gameClient;
	}
	
}

void GameService::unregisterGameClient(GameClientInterface* gameClient) {
	if (gameClient) {
		if (this->m_observerMap.count(gameClient->getClientName()) > 0) {
			std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.find(gameClient->getClientName());
			this->m_observerMap.erase(it);
		}
	}
}

void GameService::onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onMessage(client, data);
		}
	}
}

void GameService::onOpen(cocos2d::network::WebSocket* client) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onConnect(client);
		}
	}
}

void GameService::onClose(cocos2d::network::WebSocket* client) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onDisconnect(client);
		}
	}
}

void GameService::onError(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::ErrorCode& error) {
	int a = 100;
	a = 1000;
}