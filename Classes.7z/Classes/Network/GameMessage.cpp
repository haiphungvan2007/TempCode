#include "GameService.h"


std::string GameClientInterface::getClientName() {
	return this->m_clientName;
}

bool GameClientInterface::getIsClientReleased() {
	return this->m_isClientReleased;
}


GameService* GameService::m_instance = NULL;

GameService::GameService():GameClientInterface() {
	
	this->m_gameSocket = cocos2d::network::SocketIO::connect("ws://tools.itharbors.com:4000", *this);
	this->m_gameSocket->setTag("Test Client");

	//register event callbacks using the CC_CALLBACK_2() macro and passing the instance of the target class
	this->m_gameSocket->on("connect", CC_CALLBACK_2(GameService::onConnect, this));
	this->m_gameSocket->on("disconnect", CC_CALLBACK_2(GameService::onDisconnect, this));
	this->m_gameSocket->on("messageGame", CC_CALLBACK_2(GameService::onGameMessage, this));
}

GameService::~GameService() {
	if (this->m_gameSocket) {
		this->m_gameSocket->disconnect();
		this->m_gameSocket->release();
		this->m_gameSocket = NULL;
	}
	
	
}

GameService* GameService::getInstance() {
	if (m_instance == NULL) {
		m_instance = new GameService();
	}
	return m_instance;
}

void GameService::registerGameClient(GameClientInterface* gameClient) {
	if (gameClient && (this->m_observerMap.count(gameClient->getClientName()) == 0) && (!gameClient->getIsClientReleased())) {
		this->m_observerMap[gameClient->getClientName()] = gameClient;
	}
	
}

void GameService::unregisterGameClient(GameClientInterface* gameClient) {
	if (gameClient) {
		if (this->m_observerMap.count(gameClient->getClientName()) > 0) {
			std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.find(gameClient->getClientName());
			this->m_observerMap.erase(it);
		}
	}
}

void GameService::onConnect(cocos2d::network::SIOClient* client, const std::string& data) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onConnect(client, data);
		}
	}

}

void GameService::onDisconnect(cocos2d::network::SIOClient* client, const std::string& data) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onDisconnect(client, data);
		}
	}
}

void GameService::onGameMessage(cocos2d::network::SIOClient* client, const std::string& data) {
	for (std::map<std::string, GameClientInterface*>::iterator it = this->m_observerMap.begin(); it != this->m_observerMap.end(); ++it) {
		GameClientInterface* clientObject = it->second;
		if (clientObject && (!clientObject->getIsClientReleased())) {
			clientObject->onGameMessage(client, data);
		}
	}
}


void GameService::onClose(cocos2d::network::SIOClient* client) {

}

void GameService::onError(cocos2d::network::SIOClient* client, const std::string& data) {

}