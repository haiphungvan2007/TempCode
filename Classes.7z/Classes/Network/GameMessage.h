#ifndef __TetriminoSprite_H____
#define __TetriminoSprite_H____

#include "cocos2d.h"
#include "extensions/cocos-ext.h"
#include "network/SocketIO.h"
#include <stdint.h>
#include <vector>

class GameClientInterface {
private:
	std::string m_clientName = "GameClientInterface";
	bool m_isClientReleased = false;
public:
	virtual void onConnect(cocos2d::network::SIOClient* client, const std::string& data) = 0;
	virtual void onDisconnect(cocos2d::network::SIOClient* client, const std::string& data) = 0;
	virtual void onGameMessage(cocos2d::network::SIOClient* client, const std::string& data) = 0;
	virtual std::string getClientName();
	virtual bool getIsClientReleased();
};

class GameService : public GameClientInterface
	, public cocos2d::network::SocketIO::SIODelegate
{
private:
	static GameService* m_instance;
	bool m_isReleased;
	bool m_isConnected;
	std::map<std::string, GameClientInterface*> m_observerMap;
	cocos2d::network::SIOClient* m_gameSocket;
	GameService();
	~GameService();
public:
	
	static GameService* getInstance();

	void registerGameClient(GameClientInterface* gameClient);
	void unregisterGameClient(GameClientInterface* gameClient);

	//Implement for client
	void onConnect(cocos2d::network::SIOClient* client, const std::string& data);
	void onDisconnect(cocos2d::network::SIOClient* client, const std::string& data);
	void onGameMessage(cocos2d::network::SIOClient* client, const std::string& data);


	//Implement for SocketIO
	void onClose(cocos2d::network::SIOClient* client);
	void onError(cocos2d::network::SIOClient* client, const std::string& data);
	
};
#endif
