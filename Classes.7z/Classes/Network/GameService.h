#ifndef __GameService_H____
#define __GameService_H____

#include "cocos2d.h"
#include "extensions/cocos-ext.h"
#include "network/WebSocket.h"
#include <stdint.h>
#include <vector>


class GameClientInterface {
private:
	std::string m_clientName = "GameClientInterface";
	bool m_isClientReleased = false;
public:
	GameClientInterface();
	GameClientInterface(std::string clientName);
	virtual void onConnect(cocos2d::network::WebSocket* client);
	virtual void onDisconnect(cocos2d::network::WebSocket* client);
	virtual void onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data);
	virtual void onLogin(bool isSucees, std::string responseMessage);
	virtual std::string getClientName();
	virtual bool getIsClientReleased();
};

class GameService : public cocos2d::network::WebSocket::Delegate
{
private:
	static GameService* m_instance;
	bool m_isReleased;
	bool m_isConnected;
	std::map<std::string, GameClientInterface*> m_observerMap;
	cocos2d::network::WebSocket* m_gameSocket;
	GameService();
	~GameService();
public:
	
	static GameService* getInstance();

	void registerGameClient(GameClientInterface* gameClient);
	void unregisterGameClient(GameClientInterface* gameClient);

	//Implement for Websocket
	virtual void onOpen(cocos2d::network::WebSocket* client) override;
	virtual void onMessage(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::Data& data)override;
	virtual void onClose(cocos2d::network::WebSocket* client) override;
	virtual void onError(cocos2d::network::WebSocket* client, const cocos2d::network::WebSocket::ErrorCode& error)override;


	bool login(std::string userName, std::string password, std::string &error);
	bool createAccount(std::string userName, std::string password, std::string &error);
	bool connect(std::string &error);
	bool reConnect(std::string &error);
	bool joinRomm(std::string roomID, std::string &error);
	bool createRoom(std::string roomName, std::string& outputRoomID, std::string &error);
	bool sendMessage(const char* data, int dataSize, std::string &error);
};
#endif
