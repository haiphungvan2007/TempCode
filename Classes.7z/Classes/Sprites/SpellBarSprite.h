#ifndef __SpellBarSprite_H____
#define __SpellBarSprite_H____

#include "cocos2d.h"
#include "../Commons/GameDefine.h"
#include "PixelSprite.h"
class SpellBarSprite : public cocos2d::Node
{
private:
	std::vector<PixelSprite*> m_Matrix;
	~SpellBarSprite();
public:
	virtual bool init();
	CREATE_FUNC(SpellBarSprite);
	void refreshBar();
	void updatePixcelSize(float width, float height);
	
};

#endif
