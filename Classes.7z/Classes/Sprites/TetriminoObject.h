#ifndef __TetriminoSprite_H____
#define __TetriminoSprite_H____

#include "../Commons/GameDefine.h"
#include <stdint.h>
#include <vector>

class TetriminoObject
{
private:
	std::vector<std::vector<TetriminoType>> m_maxtrix;
	std::vector<std::vector<TetriminoType>> m_boudaryMatrix;
	int32_t m_posX = 0;
	int32_t m_posY = 0;
	int32_t m_rotateCount = 0;
	bool m_isVisble = false;
public:
	void rotate90();
	void rotate90(TetriminoObject& input);
	std::vector<std::vector<TetriminoType>> rotate90(std::vector<std::vector<TetriminoType>>, uint32_t rotateCount);
	void setPosition(int32_t newX, int32_t newY);
	void setMatrix(std::vector<std::vector<TetriminoType>> inputMatrix);
	void setRotateCount(int32_t newVal);
	void setVisble(bool newVal);

	std::vector<std::vector<TetriminoType>> getMaxtrix();
	std::vector<std::vector<TetriminoType>> getTemplateMaxtrix();
	TetriminoObject getTetriminoBoundary();
	int32_t getPosX();
	int32_t getPosY();
	int32_t getRotateCount();
	bool getIsVisible();
};
#endif
