#ifndef __TETRI_BOARD_H____
#define __TETRI_BOARD_H____

#include "cocos2d.h"
#include "../Commons/GameDefine.h"
#include "PixelSprite.h"
#include "TetriSprite.h"
#include "TetriminoObject.h"

#include <functional>
#include <vector>

class GameScene;

class TetriBoard : public cocos2d::Sprite
{
private:	
	cocos2d::Sprite* m_backgroudNode = NULL;
	cocos2d::LayerColor* m_blackNode = NULL;
	std::vector<std::vector<PixelSprite*>> m_matrix;
	TetriminoObject m_tetrimino;
	uint64_t m_gamePoint = 0;
	bool m_isScoring = false;
	bool m_isMovable = true;
	float m_picelWidth = 0;
	float m_picelHeight = 0;
	GameScene* parentScene = nullptr;

	std::vector<TetriminoType> randomNewRow();
	
public:
	std::vector<std::vector<std::vector<TetriminoType>>> m_nextList;

	std::function<void(bool isBigScore)> onScoring = nullptr;
	std::function<void()> onMoveDown = nullptr;
	std::function<void()> onDeath = nullptr;
	std::function<void()> onTurn = nullptr;

	virtual bool init();
	CREATE_FUNC(TetriBoard);
	
	void updateMatrix(std::vector<std::vector<TetriminoType>> newMatrix);
	void updateBoardSize(float newX, float newY);
	void checkColisionWithTetrimino(TetriminoObject inputTetriMino, bool& isColision, bool isNeedUpdateBoard);
	void updateHint(bool andFinishMoved, bool needGetNex = true);

	void moveTetriminoHorizontal(int32_t direction);
	void moveTetriminoDown(bool isFinishMoved = false);
	void turnTetrimino();

	bool checkPoint();
	bool checkIsDeath();

	void setParentScene(GameScene* parent);
	
	std::vector<std::vector<std::vector<TetriminoType>>> getNextList();
	void getNextTetrimino();

	void addMoreRow(int numberOfRow, bool isSpell = false);
	void rockTheBoard();

	void setBlindMode();
	void setGravityMode();

	void addFullRow(int numberOfRow);
	void removeRow(int numberOfRow);

	void doAlign();
};

#endif
