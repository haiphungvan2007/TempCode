#ifndef __PixelSprite_H____
#define __PixelSprite_H____

#include "cocos2d.h"
#include "../Commons/GameDefine.h"
class PixelSprite : public cocos2d::Sprite
{
private:
	TetriminoType m_type = TetriminoType::EMPTY;

public:
	virtual bool init();
	CREATE_FUNC(PixelSprite);

	void updatePixcelSize(const cocos2d::Size &newSize);
	void updateType(TetriminoType newType);	

	TetriminoType getType();
	
	float m_displayWidth = 0;
	float m_displayHeight = 0;
};

#endif
