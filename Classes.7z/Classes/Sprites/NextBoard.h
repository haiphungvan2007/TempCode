#ifndef __NextBoard_H____
#define __NextBoard_H____

#include "cocos2d.h"
#include "../Commons/GameDefine.h"
#include "TetriSprite.h"
class NextBoard : public cocos2d::Node
{
private:
	std::vector<std::vector<std::vector<TetriminoType>>> m_nextList;
	float pixcelWidth = 0;
	float pixcelHeight = 0;
	void updateAll();
public:
	virtual bool init();
	CREATE_FUNC(NextBoard);
	void updatePixcelSize(float newPixcelWidth, float newPixcelHeight);
	void updateNextList(std::vector<std::vector<std::vector<TetriminoType>>> newNextList);
	
};

#endif
