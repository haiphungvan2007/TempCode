#include "SimpleAudioEngine.h"
#include "TetriBoard.h"
#include "../Commons/GameUtils.h"
#include "../Commons/GameStatus.h"
#include "../Scenes/GameScene.h"

bool TetriBoard::init() {
	//////////////////////////////
	// 1. super init first
	if (!Sprite::init())
	{
		return false;
	}

	this->m_backgroudNode = cocos2d::Sprite::create();
	this->m_backgroudNode->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName("board"));
	this->addChild(this->m_backgroudNode);

	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		std::vector<PixelSprite*> tempVector;
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			PixelSprite* newTetrimino = PixelSprite::create();			
			tempVector.push_back(newTetrimino);
			this->addChild(newTetrimino);
		}
		this->m_matrix.push_back(tempVector);
	}	

	this->m_blackNode = cocos2d::LayerColor::create(cocos2d::Color4B(BLACK_ZONE_COLOR, 255));
	this->m_blackNode->setVisible(false);
	this->addChild(this->m_blackNode);

	this->runAction(cocos2d::RepeatForever::create(
		cocos2d::Sequence::create(
		cocos2d::DelayTime::create(GameStatus::getInstance()->getTimeDelay()),
		cocos2d::CallFunc::create(CC_CALLBACK_0(TetriBoard::moveTetriminoDown, this, false)),
		NULL)));
	return true;
}

void TetriBoard::updateMatrix(std::vector<std::vector<TetriminoType>> newMatrix) {
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			this->m_matrix[i][j]->updateType(newMatrix[i][j]);
		}
	}
}

void TetriBoard::updateBoardSize(float newWidth, float newHeight) {
	float cellSizeWidth = newWidth / TETRIS_BOARD_COLUMN;
	float cellSizeHeight = newHeight / TETRIS_BOARD_ROW;

	this->m_picelWidth = cellSizeWidth;
	this->m_picelHeight = cellSizeHeight;
			
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			float tempX = j * cellSizeWidth;
			float tempY = (float)(TETRIS_BOARD_ROW - i) * cellSizeHeight;
			this->m_matrix[i][j]->setAnchorPoint(cocos2d::Vec2(0.0, 1.0));
			this->m_matrix[i][j]->setPosition(cocos2d::Vec2(tempX, tempY));
			this->m_matrix[i][j]->updatePixcelSize(cocos2d::Size(cellSizeWidth, cellSizeHeight));
		}
	}	

	this->m_backgroudNode->setContentSize(cocos2d::Size(newWidth, newWidth * 787.0f / 289.0f));
	this->m_backgroudNode->setAnchorPoint(cocos2d::Vec2(0, 0));
	this->m_backgroudNode->setPosition(cocos2d::Vec2(0, 0));
	this->m_blackNode->setContentSize(cocos2d::Size(newWidth, newHeight));
}

void TetriBoard::checkColisionWithTetrimino(TetriminoObject inputTetriMino, bool& isColision, bool isNeedUpdateBoard) {
	isColision = false;
	
	//Copy current board state
	std::vector<std::vector<TetriminoType>> tempMatrix;
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		std::vector<TetriminoType> tempVector;
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			TetriminoType tempType = this->m_matrix[i][j]->getType();
			if (GameUtils::isObstackTetriminoType(tempType)) {
				tempVector.push_back(tempType);
			}
			else {
				tempVector.push_back(TetriminoType::EMPTY);
			}
			
		}
		tempMatrix.push_back(tempVector);
	}
	

	std::vector<std::vector<TetriminoType>> inputMatrix = inputTetriMino.getMaxtrix();
	//Current tetrimnino position is out of board range => is collision
	if ((inputTetriMino.getPosX() < 0) ||
		((inputTetriMino.getPosX() + (int32_t)inputMatrix[0].size()) >= (TETRIS_BOARD_COLUMN + 1)) ||
		((inputTetriMino.getPosY() + (int32_t)inputMatrix.size()) >= (TETRIS_BOARD_ROW + 1))) {
		isColision = true;
		return;
	}

	for (int64_t tempY = 0; tempY < inputMatrix.size(); tempY++) {
		for (int64_t tempX = 0; tempX < inputMatrix[0].size(); tempX++) {
			int32_t iCol = tempX + inputTetriMino.getPosX();
			int32_t iRow = tempY + inputTetriMino.getPosY();
			if (iRow >= 0) {
				TetriminoType boardPointType = tempMatrix[iRow][iCol];
				TetriminoType tetriminoPointType = inputMatrix[tempY][tempX];

				// Both two points are empty type
				if (GameUtils::isEmptyTetriminoType(boardPointType) && GameUtils::isEmptyTetriminoType(tetriminoPointType)) {
					//Do nothing
				} 
				// Both two points are not empty type
				else if ((GameUtils::isEmptyTetriminoType(boardPointType) == false) && 
					(GameUtils::isEmptyTetriminoType(tetriminoPointType) == false)){
					isColision = true;
					break;
				} 
				// Other case
				else {
					TetriminoType newType = GameUtils::isEmptyTetriminoType(boardPointType) ? tetriminoPointType : boardPointType;					
					tempMatrix[iRow][iCol] = newType;
				}
			}
			
		}
		if (isColision) {
			break;
		}

	}

	if ((!isColision) && (isNeedUpdateBoard)) {
		this->updateMatrix(tempMatrix);		
	}

	//Release temp board state
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		tempMatrix[i].clear();
	}
	tempMatrix.clear();	
}

void TetriBoard::updateHint(bool andFinishMoved, bool needGetNext) {
	
	if (this->m_tetrimino.getIsVisible()) {		

		TetriminoObject tempTetri;
		tempTetri.setMatrix(this->m_tetrimino.getMaxtrix());
		tempTetri.setPosition(this->m_tetrimino.getPosX(), this->m_tetrimino.getPosY());
		int32_t tempX = tempTetri.getPosX();
		int32_t tempY = tempTetri.getPosY();
		while (tempY < TETRIS_BOARD_ROW) {
			bool isColission = false;
			tempTetri.setPosition(tempX, tempY);
			this->checkColisionWithTetrimino(tempTetri, isColission, false);
			if (isColission) {
				tempTetri.setPosition(tempX, tempY - 1);
				break;
			}
			tempY++;
		}

		float tempHintX = (float)tempTetri.getPosX() * this->m_picelWidth;
		float tempHintY = ((float)TETRIS_BOARD_ROW - (float)tempTetri.getPosY() - (float)(tempTetri.getMaxtrix()[0].size() - tempTetri.getMaxtrix().size())) * this->m_picelHeight;


		this->m_blackNode->removeAllChildren();

		//Update matrix for hint
		for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
			for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
				PixelSprite* tempObject = this->m_matrix[i][j];
				if (GameUtils::isHintTetriminoType(tempObject->getType())) {
					tempObject->updateType(TetriminoType::EMPTY);
				}
			}
		}

		std::vector<std::vector<TetriminoType>> tetriminoMatrix = tempTetri.getMaxtrix();
		for (int64_t i = 0; i < tetriminoMatrix.size(); i++) {
			for (int64_t j = 0; j < tetriminoMatrix[0].size(); j++) {
				int32_t iCol = tempTetri.getPosX() + j;
				int32_t iRow = tempTetri.getPosY() + i;
				if (iRow >= 0) {
					if (GameUtils::isEmptyTetriminoType(tetriminoMatrix[i][j])) {
						//Do nothing
					}
					else {
						if (andFinishMoved) {
							if (tetriminoMatrix[i][j] != TetriminoType::SPELL) {
								this->m_matrix[iRow][iCol]->updateType(TetriminoType::NORMAL);
							}
							else {
								this->m_matrix[iRow][iCol]->updateType(TetriminoType::NORMAL_SPELL);
							}
							
						}
						else {
							if (tetriminoMatrix[i][j] != TetriminoType::SPELL) {
								this->m_matrix[iRow][iCol]->updateType(TetriminoType::HINT);
							}
							else {
								this->m_matrix[iRow][iCol]->updateType(TetriminoType::HINT_SPELL);
							}

							if (GameUtils::isHintTetriminoType(this->m_matrix[iRow][iCol]->getType())) {
								PixelSprite* newPicel = PixelSprite::create();
								newPicel->updatePixcelSize(cocos2d::Size(this->m_picelWidth, this->m_picelHeight));
								newPicel->updateType(this->m_matrix[iRow][iCol]->getType());
								float tempX = iCol * this->m_picelWidth;
								float tempY = (float)(TETRIS_BOARD_ROW - iRow) * this->m_picelHeight;
								newPicel->setAnchorPoint(cocos2d::Vec2(0.0, 1.0));
								newPicel->setPosition(cocos2d::Vec2(tempX, tempY));
								this->m_blackNode->addChild(newPicel);
							}
							
						}
					}
					
					
				}
			}
		}
		if (andFinishMoved) {
			this->m_tetrimino.setVisble(false);

			bool isScore = this->checkPoint();
			
			// Check is blind mode
			if (GameStatus::getInstance()->m_BlindTurn > 0) {
				GameStatus::getInstance()->m_BlindTurn -= 1;
			}
			else {
				this->m_blackNode->setVisible(false);
			}

			// Check is gravity mode
			if (GameStatus::getInstance()->m_GravityTurn > 0) {
				GameStatus::getInstance()->m_GravityTurn -= 1;

				if (isScore) {
					//Update board
					for (int64_t column = 0; column < this->m_matrix[0].size(); column++) {
						std::vector<TetriminoType> emptyColumn;
						bool canDrop = true;
						for (int64_t row = 0; row < this->m_matrix.size(); row++) {
							if (GameUtils::isObstackTetriminoType(this->m_matrix[row][column]->getType())) {
								if (this->m_matrix[row][column]->getType() == TetriminoType::NORMAL_SPELL) {
									canDrop = false;
								}
								else {
									canDrop = true;
								}
								emptyColumn.push_back(this->m_matrix[row][column]->getType());
							}
							else {
								if (!canDrop) {
									emptyColumn.push_back(TetriminoType::EMPTY);
								}
							}
						}

						for (int64_t row = this->m_matrix.size() - 1; row >= 0; row--) {
							int delta = this->m_matrix.size() - row;
							if (delta < emptyColumn.size()) {
								this->m_matrix[row][column]->updateType(emptyColumn[emptyColumn.size() - 1 - delta]);
							}
							else {
								this->m_matrix[row][column]->updateType(TetriminoType::EMPTY);
							}
						}
					}
					this->checkPoint();
				}				
			}

			this->checkIsDeath();

			if (this->onMoveDown) {
				this->onMoveDown();
			}

			if (needGetNext) {
				this->getNextTetrimino();
			}
			
		}
		else {
			std::vector<std::vector<TetriminoType>> inputMatrix = this->m_tetrimino.getMaxtrix();			
			for (int64_t tempY = 0; tempY < inputMatrix.size(); tempY++) {
				for (int64_t tempX = 0; tempX < inputMatrix[0].size(); tempX++) {
					int32_t iCol = tempX + this->m_tetrimino.getPosX();
					int32_t iRow = tempY + this->m_tetrimino.getPosY();
					if (iRow >= 0) {
						TetriminoType tempType = inputMatrix[tempY][tempX];
						if (!GameUtils::isEmptyTetriminoType(tempType)) {
							this->m_matrix[iRow][iCol]->updateType(tempType);
						}
						
					}
				}				
			}
		}			
	}
	
}

void TetriBoard::moveTetriminoHorizontal(int32_t direction) {
	if (this->m_tetrimino.getIsVisible() && this->m_isMovable) {
		int32_t preX = this->m_tetrimino.getPosX();
		int32_t preY = this->m_tetrimino.getPosY();

		this->m_tetrimino.setPosition(preX + direction, preY);
		bool isCollision = false;
		this->checkColisionWithTetrimino(this->m_tetrimino, isCollision, true);
		if (isCollision) {
			this->m_tetrimino.setPosition(preX, preY);
		}
		this->updateHint(false);
	}
}

void TetriBoard::moveTetriminoDown(bool isFinishMoved) {
	if (this->m_tetrimino.getIsVisible() && this->m_isMovable) {
		if (isFinishMoved) {			
			this->updateHint(true);					
			return;
		}
		
		int32_t preX = this->m_tetrimino.getPosX();
		int32_t preY = this->m_tetrimino.getPosY();

		this->m_tetrimino.setPosition(preX, preY + 1);
		bool isCollision = false;
		this->checkColisionWithTetrimino(this->m_tetrimino, isCollision, true);
		if (isCollision) {
			this->m_tetrimino.setPosition(preX, preY);
			this->updateHint(true);			
			this->getNextTetrimino();
		}
		else {
			this->updateHint(false);
		}				
	}
}

void TetriBoard::turnTetrimino() {
	if (this->m_tetrimino.getIsVisible() && this->m_isMovable) {
		bool isCollision = false;

		TetriminoObject tempTetri;
		this->m_tetrimino.rotate90(tempTetri);
		this->checkColisionWithTetrimino(tempTetri, isCollision, false);
		if (!isCollision) {
			this->m_tetrimino.rotate90();
			this->checkColisionWithTetrimino(this->m_tetrimino, isCollision, true);
			
			if (this->onTurn) {
				this->onTurn();
			}
			this->updateHint(false);
		}
		
	}
}

bool TetriBoard::checkPoint() {
	bool isScore = false;
	this->m_isScoring = true;
	std::vector<std::vector<TetriminoType>> tempMatrix;
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		std::vector<TetriminoType> tempVector;
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {			
			tempVector.push_back(TetriminoType::EMPTY);
		}
		tempMatrix.push_back(tempVector);
	}

	int numberScore = 0;
	int32_t rowIndex = TETRIS_BOARD_ROW - 1;
	for (int32_t i = (TETRIS_BOARD_ROW - 1); i >= 0; i--) {
		bool isFullRow = true;
		bool hasRockInRow = false;
		int tempSpellCount = 0;
		std::vector<TetriminoType> tempRowMatrix;
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			PixelSprite* tempObject = this->m_matrix[i][j];			
			if (GameUtils::isEmptyTetriminoType(tempObject->getType())) {
				isFullRow = false;
				break;
			}

			if (tempObject->getType() == TetriminoType::ROCK) {
				hasRockInRow = true;
				tempRowMatrix.push_back(TetriminoType::NORMAL);
			}
			else {
				tempRowMatrix.push_back(TetriminoType::EMPTY);
			}

			if (tempObject->getType() == TetriminoType::NORMAL_SPELL) {
				tempSpellCount++;
			}
		}
		if (isFullRow) {
			isScore = true;
			this->m_gamePoint++;
			numberScore++;
			if (tempSpellCount > 0) {
				int tempValue = GameStatus::getInstance()->m_NumberOfSpell + tempSpellCount;
				GameStatus::getInstance()->m_NumberOfSpell = tempValue > MAX_SPELL_COUNT ? MAX_SPELL_COUNT : tempValue;
				this->parentScene->getSpellBar()->refreshBar();
			}

			if (hasRockInRow) {
				tempMatrix[rowIndex] = tempRowMatrix;
				rowIndex -= 1;
			}
		}
		else {
			for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
				tempMatrix[rowIndex][j] = this->m_matrix[i][j]->getType();
			}
			rowIndex -= 1;
		}
	}

	
	if ((numberScore > 0) && this->onScoring) {
		this->onScoring(numberScore >= BIG_SCORE);
	}
	

	this->updateMatrix(tempMatrix);
	this->m_isScoring = false;

	return isScore;
}


bool TetriBoard::checkIsDeath() {
	for (int32_t i = 0; i < TETRIS_ADDITON_ROW; i++) {
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			if (GameUtils::isObstackTetriminoType(this->m_matrix[i][j]->getType())) {
				if (this->onDeath) {
					this->onDeath();
				}
				this->m_isMovable = false;
				GameStatus::getInstance()->m_IsDeath = true;
				return true;
			}
		}
	}
	GameStatus::getInstance()->m_IsDeath = false;
	return false;
}



void TetriBoard::getNextTetrimino() {
	std::vector<std::vector<std::vector<TetriminoType>>> nextList = GameStatus::getInstance()->getNext1();
	std::vector<std::vector<TetriminoType>> templateMatrix = nextList[0];

	this->m_nextList.clear();
	for (int i = 1; i < nextList.size(); i++) {
		this->m_nextList.push_back(nextList[i]);
	}

	this->m_tetrimino.setMatrix(templateMatrix);
	this->m_tetrimino.setPosition(3, 0);
	this->m_tetrimino.setVisble(true);
	bool isColision = false;
	this->checkColisionWithTetrimino(this->m_tetrimino, isColision, true);
	this->updateHint(false);

	int32_t preSpeed = GameStatus::getInstance()->getGameSpeed();
	GameStatus::getInstance()->setTurnCount(GameStatus::getInstance()->getTurnCount() + 1);
	
	if (preSpeed != GameStatus::getInstance()->getGameSpeed()) {
		this->stopAllActions();
		float delayTime = GameStatus::getInstance()->getTimeDelay();
		this->runAction(cocos2d::RepeatForever::create(
			cocos2d::Sequence::create(
			cocos2d::DelayTime::create(delayTime),
			cocos2d::CallFunc::create(CC_CALLBACK_0(TetriBoard::moveTetriminoDown, this, false)),
			NULL)));
	}
	
	
	if (parentScene) {
		parentScene->getNextBoard()->updateNextList(this->m_nextList);
	}
	

}

std::vector<std::vector<std::vector<TetriminoType>>> TetriBoard::getNextList() {
	return this->m_nextList;
}


void TetriBoard::setParentScene(GameScene* parent) {
	this->parentScene = parent;
}

std::vector<TetriminoType> TetriBoard::randomNewRow() {
	std::vector<TetriminoType> tempRow;
	for (int32_t c = 0; c < TETRIS_BOARD_COLUMN; c++) {
		int randomIsEmpty = rand() % 2;
		int randomCount = 0;
		if (randomIsEmpty) {
			randomCount++;
		}
		if (randomCount > MAX_EMPTY_IN_ROW) {
			randomIsEmpty = true;
		}

		//Last column but there is no empty column in row => last coumn must be empty
		if ((randomCount == 0) && (c == (TETRIS_BOARD_COLUMN - 1))) {
			randomIsEmpty = true;
		}
		tempRow.push_back(randomIsEmpty ? TetriminoType::EMPTY : TetriminoType::NORMAL);
	}
	return tempRow;
}

void TetriBoard::addMoreRow(int numberOfRow, bool isSpell) {
	if (GameStatus::getInstance()->m_IsDeath) {
		return;
	}

	if (isSpell) {
		this->m_tetrimino.setVisble(false);
	}
	

	for (int r = 0; r < numberOfRow; r++) {
		//Check it will be collision
		int32_t preX = this->m_tetrimino.getPosX();
		int32_t preY = this->m_tetrimino.getPosY();

		this->m_tetrimino.setPosition(preX, preY + 1);
		bool isCollision = false;
		this->checkColisionWithTetrimino(this->m_tetrimino, isCollision, false);
		this->m_tetrimino.setPosition(preX, preY);
		if (isCollision) {
			updateHint(true);
		}
		this->checkPoint();
		if (this->checkIsDeath()) {
			return;
		}

		//Inti a new row
		std::vector<TetriminoType> newRow = this->randomNewRow();

		//Init an empty board
		std::vector<std::vector<TetriminoType>> tempMatrix;		
		for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
			std::vector<TetriminoType> tempVector;
			for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
				tempVector.push_back(TetriminoType::EMPTY);
			}
			tempMatrix.push_back(tempVector);
		}

		tempMatrix[TETRIS_BOARD_ROW - 1] = newRow;
		for (int32_t i = (TETRIS_BOARD_ROW - 2); i >= 0; i--) {
			for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {				
				PixelSprite* tempObject = this->m_matrix[i+1][j];
				if (GameUtils::isObstackTetriminoType(tempObject->getType())) {
					tempMatrix[i][j] = tempObject->getType();
				}
			}
		}
		this->updateMatrix(tempMatrix);
		
		if (this->m_tetrimino.getIsVisible()) {
			checkColisionWithTetrimino(this->m_tetrimino, isCollision, true);
			updateHint(false);
		}

		auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
		audio->preloadEffect(GAME_SOUND_DOWN);
		audio->playEffect(GAME_SOUND_DOWN);		
		
	}

	if (isSpell) {
		this->m_tetrimino.setVisble(true);
	}
	else {
		if (!this->m_tetrimino.getIsVisible()) {
			this->getNextTetrimino();
		}
	}
	
	
}

void TetriBoard::rockTheBoard() {
	
	for (int32_t i = 0; i < TETRIS_BOARD_ROW; i++) {
		for (int32_t j = 0; j < TETRIS_BOARD_COLUMN; j++) {
			PixelSprite* tempObject = this->m_matrix[i][j];
			if (GameUtils::isObstackTetriminoType(tempObject->getType()) && (tempObject->getType() != TetriminoType::NORMAL_SPELL)) {
				this->m_matrix[i][j]->updateType(TetriminoType::ROCK);
			}			
		}
	}
	
}

void TetriBoard::setBlindMode() {
	GameStatus::getInstance()->m_BlindTurn = BLIND_MAX_TURN;
	this->m_blackNode->setVisible(true);
}

void TetriBoard::setGravityMode() {
	GameStatus::getInstance()->m_GravityTurn = GRAVITY_MAX_TURN;
}

void TetriBoard::addFullRow(int numberOfRow) {
	if (GameStatus::getInstance()->m_IsDeath) {
		return;
	}
	this->m_tetrimino.setVisble(false);

	for (int i = 0; i < numberOfRow; i++) {
		int r = TETRIS_BOARD_ROW - 1 - i;
		for (int32_t c = 0; c < TETRIS_BOARD_COLUMN; c++) {
			PixelSprite* tempObject = this->m_matrix[r][c];
			if (tempObject->getType() != TetriminoType::NORMAL_SPELL) {
				this->m_matrix[r][c]->updateType(TetriminoType::NORMAL);
			}
			else {
				this->m_matrix[r][c]->updateType(TetriminoType::NORMAL_SPELL);
			}


		}
	}

	this->getNextTetrimino();

}

void TetriBoard::removeRow(int numberOfRow) {
	if (GameStatus::getInstance()->m_IsDeath) {
		return;
	}
	
	for (int64_t row = this->m_matrix.size() - 1; row >= 0; row--) {
		for (int64_t column = 0; column < this->m_matrix[0].size(); column++) {
			int tempRow = row - numberOfRow;
			TetriminoType tempType = this->m_matrix[row][column]->getType();

			if (GameUtils::isMovableTetriminoType(tempType)) {
				continue;
			}

			tempType = TetriminoType::EMPTY;
			if (tempRow >= 0) {
				tempType = this->m_matrix[tempRow][column]->getType();
			}
			
			if (GameUtils::isObstackTetriminoType(tempType) || (tempType == TetriminoType::EMPTY) || GameUtils::isHintTetriminoType(tempType)) {
				this->m_matrix[row][column]->updateType(tempType);
			}
		}
	}



	auto audio = CocosDenshion::SimpleAudioEngine::getInstance();
	audio->preloadEffect(GAME_SOUND_DOWN);
	audio->playEffect(GAME_SOUND_DOWN);
}

void TetriBoard::doAlign() {
	if (GameStatus::getInstance()->m_IsDeath) {
		return;
	}
	this->m_tetrimino.setVisble(false);

	for (int64_t row = 0; row < this->m_matrix.size(); row++) {
		std::vector<TetriminoType> tempRow;
		
		for (int64_t column = 0; column < this->m_matrix[0].size(); column++) {
			TetriminoType tempType = this->m_matrix[row][column]->getType();
			if (GameUtils::isObstackTetriminoType(tempType)) {
				tempRow.push_back(tempType);
			}
		}

		for (int64_t column = 0; column < this->m_matrix[0].size(); column++) {
			if (column < tempRow.size()) {
				this->m_matrix[row][column]->updateType(tempRow[column]);
			}
			else {
				this->m_matrix[row][column]->updateType(TetriminoType::EMPTY);
			}
		}
	}

	this->getNextTetrimino();
}