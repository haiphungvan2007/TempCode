#ifndef __TetriSprite_H____
#define __TetriSprite_H____

#include "cocos2d.h"
#include "../Commons/GameDefine.h"
class TetriSprite : public cocos2d::Sprite
{
private:
	std::vector<std::vector<TetriminoType>> m_matrix;
	float pixcelWidth = 0;
	float pixcelHeight = 0;
	void updateAll();
public:
	virtual bool init();
	CREATE_FUNC(TetriSprite);
	void updatePixcelSize(float newPixcelWidth, float newPixcelHeight);
	void updateMatrix(std::vector<std::vector<TetriminoType>> newMatrix, bool needConvertToHint = false);
	
};

#endif
