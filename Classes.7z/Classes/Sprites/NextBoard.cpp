#include "NextBoard.h"
#include "TetriSprite.h"
#include "../Commons/GameUtils.h"

bool NextBoard::init() {
	//////////////////////////////
	// 1. super init first
	if (!Node::init())
	{
		return false;
	}

	return true;
}

void NextBoard::updateAll() {
	this->removeAllChildren();

	float oneTetriWidth = pixcelWidth * 6.0f;
	float oneTetriHeight = pixcelHeight * 4.0f;

	float newContentWidth = oneTetriWidth;
	float newContentHeight = oneTetriHeight * (float)NEXT_IN_VIEW;

	cocos2d::LayerColor* colorNode0 = cocos2d::LayerColor::create(cocos2d::Color4B(BORDER_COLOR, 255));
	this->addChild(colorNode0);
	colorNode0->setContentSize(cocos2d::Size(newContentWidth, newContentHeight));

	cocos2d::LayerColor* colorNode1 = cocos2d::LayerColor::create(cocos2d::Color4B(cocos2d::Color3B::WHITE, 255));
	colorNode1->setPositionX(T_BORDER_WIDTH);
	colorNode1->setPositionY(T_BORDER_WIDTH);
	this->addChild(colorNode1);
	colorNode1->setContentSize(cocos2d::Size(newContentWidth - 2.0f * T_BORDER_WIDTH, newContentHeight - 2.0f * T_BORDER_WIDTH));

	for (int i = 0; (i < NEXT_IN_VIEW) && (i < this->m_nextList.size()); i++) {
		TetriSprite* newTetriSprite = TetriSprite::create();
		newTetriSprite->updatePixcelSize(pixcelWidth, pixcelHeight);
		newTetriSprite->updateMatrix(this->m_nextList[i]);

		float tempX = (oneTetriWidth) / 2.0f;
		float tempY = oneTetriHeight * (float)(NEXT_IN_VIEW - i) - (oneTetriHeight - newTetriSprite->getContentSize().height) / 2.0f;
		newTetriSprite->setPosition(cocos2d::Vec2(tempX, tempY));
		newTetriSprite->setAnchorPoint(cocos2d::Vec2(0.5, 1.0));
		this->addChild(newTetriSprite);
	}

	
	this->setContentSize(cocos2d::Size(newContentWidth, newContentHeight)); 
}

void NextBoard::updatePixcelSize(float newPixcelWidth, float newPixcelHeight) {
	this->pixcelWidth = newPixcelWidth;
	this->pixcelHeight = newPixcelHeight;
	this->updateAll();
}

void NextBoard::updateNextList(std::vector<std::vector<std::vector<TetriminoType>>> newNextList) {
	this->m_nextList = newNextList;
	this->updateAll();
}

