#include "PixelSprite.h"
#include "../Commons/GameUtils.h"


bool PixelSprite::init() {
	//////////////////////////////
	// 1. super init first
	if (!Sprite::init())
	{
		return false;
	}
	this->setVisible(false);

	return true;
}

void PixelSprite::updatePixcelSize(const cocos2d::Size &newSize) {
	this->setContentSize(newSize);
	this->m_displayWidth = newSize.width;
	this->m_displayHeight = newSize.height;
}


void PixelSprite::updateType(TetriminoType newType) {
	this->m_type = newType;

	//Update color
	if ((newType >= TetriminoType::SPELL) && (newType <= TetriminoType::ORANGE)) {
		this->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName(std::to_string(newType)));
	}
	else if (newType == TetriminoType::HINT) {
		this->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName(std::to_string(YELLOW)));
	}
	else if (newType == TetriminoType::HINT_SPELL) {
		this->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName(std::to_string(SPELL)));
	}
	else if ((newType == TetriminoType::NORMAL)) {
		this->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName(std::to_string(BLUE)));
	}
	else if ((newType == TetriminoType::NORMAL_SPELL)) {
		this->setSpriteFrame(cocos2d::SpriteFrameCache::getInstance()->getSpriteFrameByName(std::to_string(SPELL)));
	}
	
	//Update opacity
	float tempAlpha = 255;
	if ((newType == TetriminoType::HINT) ||
		(newType == TetriminoType::HINT_SPELL)) {
		tempAlpha = 100;
	}	
	this->setOpacity(tempAlpha);

	//Update visible	
	this->setVisible(newType != EMPTY);
	

	setContentSize(cocos2d::Size(m_displayWidth, m_displayHeight));
}

TetriminoType PixelSprite::getType() {
	return this->m_type;
}