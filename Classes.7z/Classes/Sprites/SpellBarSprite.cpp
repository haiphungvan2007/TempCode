#include "SpellBarSprite.h"
#include "../Commons/GameUtils.h"
#include "../Commons/GameStatus.h"

bool SpellBarSprite::init() {
	//////////////////////////////
	// 1. super init first
	if (!Node::init())
	{
		return false;
	}

	for (int i = 0; i < MAX_SPELL_COUNT; i++) {
		PixelSprite* pixcel = PixelSprite::create();
		pixcel->setAnchorPoint(cocos2d::Vec2(0, 0));
		this->m_Matrix.push_back(pixcel);
		this->addChild(pixcel);
	}

	return true;
}

SpellBarSprite::~SpellBarSprite() {
	this->m_Matrix.clear();
	this->removeAllChildren();
}

void SpellBarSprite::refreshBar() {
	for (int i = 0; i < MAX_SPELL_COUNT; i++) {
		if (i < GameStatus::getInstance()->m_NumberOfSpell) {
			this->m_Matrix[i]->updateType(TetriminoType::ORANGE);
		}
		else {
			this->m_Matrix[i]->updateType(TetriminoType::EMPTY);
		}
		
	}
}


void SpellBarSprite::updatePixcelSize(float width, float height) {
	for (int i = 0; i < MAX_SPELL_COUNT; i++) {
		this->m_Matrix[i]->setPosition(cocos2d::Vec2(0, (float)i * height));
		this->m_Matrix[i]->updatePixcelSize(cocos2d::Size(width, height));
	}
	this->setContentSize(cocos2d::Size(width, height * (float)MAX_SPELL_COUNT));
}

