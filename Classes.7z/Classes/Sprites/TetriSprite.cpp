#include "TetriSprite.h"
#include "PixelSprite.h"
#include "../Commons/GameUtils.h"

bool TetriSprite::init() {
	//////////////////////////////
	// 1. super init first
	if (!Sprite::init())
	{
		return false;
	}


	return true;
}

void TetriSprite::updateAll() {
	this->removeAllChildren();
	for (int i = 0; i < this->m_matrix.size(); i++) {
		for (int j = 0; j < this->m_matrix[0].size(); j++) {
			if (this->m_matrix[i][j] != TetriminoType::EMPTY) {
				PixelSprite* newTetrimino = PixelSprite::create();
				float tempX = (float)j * pixcelWidth;
				float tempY = (float)(this->m_matrix.size() - i) * pixcelHeight;
				newTetrimino->setAnchorPoint(cocos2d::Vec2(0.0, 1.0));
				newTetrimino->setPosition(cocos2d::Vec2(tempX, tempY));
				newTetrimino->updatePixcelSize(cocos2d::Size(pixcelWidth, pixcelHeight));
				newTetrimino->updateType(this->m_matrix[i][j]);
				this->addChild(newTetrimino);
			}
		}
	}

	float newContentHeight = pixcelHeight * this->m_matrix.size();
	float newContentWidth = 0.0f;
	if (this->m_matrix.size() > 0) {
		newContentWidth = pixcelWidth * this->m_matrix[0].size();
	}
	this->setContentSize(cocos2d::Size(newContentWidth, newContentHeight)); 
}

void TetriSprite::updatePixcelSize(float newPixcelWidth, float newPixcelHeight) {
	this->pixcelWidth = newPixcelWidth;
	this->pixcelHeight = newPixcelHeight;
	this->updateAll();
}

void TetriSprite::updateMatrix(std::vector<std::vector<TetriminoType>> newMatrix, bool needConvertToHint) {
	this->m_matrix = newMatrix;
	if (needConvertToHint) {
		for (int i = 0; i < this->m_matrix.size(); i++) {
			for (int j = 0; j < this->m_matrix[0].size(); j++) {
				TetriminoType tempType = this->m_matrix[i][j];
				if (!GameUtils::isEmptyTetriminoType(tempType)) {
					if (tempType == TetriminoType::SPELL) {
						this->m_matrix[i][j] = TetriminoType::HINT_SPELL;
					}
					else {
						this->m_matrix[i][j] = TetriminoType::HINT;
					}
				}
			}
		}
	}
	this->updateAll();
}