#include "TetriminoObject.h"

void TetriminoObject::rotate90() {
	if ((this->m_isVisble) && (this->m_maxtrix.size() >0) && (this->m_maxtrix.size() != this->m_maxtrix[0].size())) {
		this->m_rotateCount += 1;
		this->m_rotateCount = this->m_rotateCount % 4;
		int32_t delta = (int32_t)(this->m_maxtrix[0].size() - this->m_maxtrix.size()) / 2;
		this->m_posX += delta;
		this->m_posY -= delta;
		this->m_maxtrix = this->rotate90(this->m_maxtrix, 1);
	}
}

void TetriminoObject::rotate90(TetriminoObject& input) {
	input.setMatrix(this->m_maxtrix);
	input.setPosition(m_posX, m_posY);
	input.setVisble(true);
	input.rotate90();
}

std::vector<std::vector<TetriminoType>> TetriminoObject::rotate90(std::vector<std::vector<TetriminoType>> input, uint32_t rotateCount) {
	int32_t inputRow = input.size();
	if (inputRow <= 0) {
		return input;
	}

	int32_t inputCol = input[0].size();
	if (inputCol <= 0) {
		return input;
	}

	int32_t outputRow = inputRow;
	int32_t outputCol = inputCol;

	if ((rotateCount % 2) == 1) {
		outputRow = inputCol;
		outputCol = inputRow;
	}

	//Init retval matrix
	std::vector<std::vector<TetriminoType>> retVal;
	for (int32_t i = 0; i < outputRow; i++) {
		retVal.push_back(std::vector<TetriminoType>(outputCol));
	}
	uint32_t tempAngle = rotateCount % 4;
	//Rotate 0
	if (tempAngle == 0) {
		return input;
	}

	//Rotate 90
	else if (tempAngle == 1) {
		int32_t index = 0;
		for (int32_t j = (outputCol - 1); j >= 0; j--) {
			for (int32_t i = 0; i < outputRow; i++) {
				int32_t r = index / inputCol;
				int32_t c = index % inputCol;
				retVal[i][j] = input[r][c];
				index++;
			}
		}
	}

	//Rotate 180
	else if (tempAngle == 2) {
		int32_t index = 0;
		for (int32_t i = (outputRow - 1); i >= 0; i--) {
			for (int32_t j = (outputCol - 1); j >= 0; j--) {
				int32_t r = index / inputCol;
				int32_t c = index % inputCol;
				retVal[i][j] = input[r][c];
				index++;
			}
		}
	}

	//Rotate 270
	else if (tempAngle == 3) {
		int32_t index = 0;
		for (int32_t j = 0; j < outputCol; j++){
			for (int32_t i = (outputRow - 1); i >= 0; i--) {
				int32_t r = index / inputCol;
				int32_t c = index % inputCol;
				retVal[i][j] = input[r][c];
				index++;
			}
		}
	}

	return retVal;
}

void TetriminoObject::setRotateCount(int32_t newVal) {
	this->m_rotateCount = newVal;
}

void TetriminoObject::setPosition(int32_t newX, int32_t newY) {
	this->m_posX = newX;
	this->m_posY = newY;

}

void TetriminoObject::setMatrix(std::vector<std::vector<TetriminoType>> inputMatrix) {
	this->m_maxtrix = inputMatrix;
	uint32_t maxSize = 0;
	if (inputMatrix.size() > 0) {
		maxSize = (inputMatrix.size() > inputMatrix[0].size()) ? inputMatrix.size() : inputMatrix[0].size();
	}

	//Clear boundary matrix
	for (int i = 0; i < this->m_boudaryMatrix.size(); i++) {
		this->m_boudaryMatrix[i].clear();
	}
	this->m_boudaryMatrix.clear();

	if (maxSize > 0) {
		for (int i = 0; i < maxSize; i++) {
			std::vector<TetriminoType> tempVector;
			for (int j = 0; j < maxSize; j++) {
				tempVector.push_back(TetriminoType::NORMAL);
			}
			this->m_boudaryMatrix.push_back(tempVector);
		}
	}

	int a;
	a = 100;
}

std::vector<std::vector<TetriminoType>> TetriminoObject::getMaxtrix() {
	return this->m_maxtrix;
}

std::vector<std::vector<TetriminoType>> TetriminoObject::getTemplateMaxtrix() {
	std::vector<std::vector<TetriminoType>> retVal = this->m_maxtrix;
	for (int i = 0; i < retVal.size(); i++) {		
		for (int j = 0; j < retVal[0].size(); j++) {
			if (retVal[i][j] == TetriminoType::SPELL) {
				retVal[i][j] = TetriminoType::RED;
			}
		}
	}
	return retVal;
}

TetriminoObject TetriminoObject::getTetriminoBoundary() {
	TetriminoObject retVal;
	retVal.setMatrix(this->m_boudaryMatrix);
	int32_t delta = (this->m_maxtrix[0].size() - this->m_maxtrix.size()) / 2;

	int32_t tempX = this->m_posX;
	int32_t tempY = this->m_posY;
	if (delta > 0) {
		tempY -= delta;
	}
	else if (delta < 0) {
		tempX -= delta;
	}
	retVal.setPosition(tempX, tempY);
	return retVal;
}



int32_t TetriminoObject::getPosX() {
	return this->m_posX;
}

int32_t TetriminoObject::getPosY() {
	return this->m_posY;
}

int32_t TetriminoObject::getRotateCount() {
	return this->m_rotateCount;
}

void TetriminoObject::setVisble(bool newVal) {
	this->m_isVisble = newVal;
}

bool TetriminoObject::getIsVisible() {
	return this->m_isVisble;
}