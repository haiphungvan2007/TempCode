/**********************************************
 *********   UTS VERSION : 1.5.0-a2    *********
 **********************************************/


#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <dlfcn.h>

// Include Source File for testing!!

#include "../EventHandler/CEvtHandlerFromMgrAppMain.hpp"

// Include MOCK FILES!!
#include "mock/src/CMgrIap_mock.h"

/*
 * Define Mock/Mock function
 */
class BaseCEvtHandlerFromMgrAppMain {
public:
    virtual ~BaseCEvtHandlerFromMgrAppMain(){  }
};

class MockCEvtHandlerFromMgrAppMain : public BaseCEvtHandlerFromMgrAppMain {
public:
};

MockCEvtHandlerFromMgrAppMain *M_CEvtHandlerFromMgrAppMain;

using ::testing::Return;
using ::testing::_;
using ::testing::A;
using ::testing::ReturnRef;
using ::testing::Values;
using ::testing::SetArgPointee;
using ::testing::SetArrayArgument;
using ::testing::SaveArg;
using ::testing::SaveArgPointee;
using ::testing::DoAll;
using ::testing::Args;
using ::testing::AllOf;
using ::testing::AtLeast;
using ::testing::Combine;
using ::testing::InSequence;
class CEvtHandlerFromMgrAppMainTest : public ::testing::Test {
protected:
    virtual void SetUp() {
        M_CMgrIap = new testing::NiceMock<MockCMgrIap>();
        testObj = new CEvtHandlerFromMgrAppMain;

    }
    virtual void TearDown() {

       delete M_CMgrIap;
    }
    CEvtHandlerFromMgrAppMain* testObj;
};

/**
*   @brief This is a test script for the sendFirstDataToApp function
*   @classID CAccessVehiData
*   @methodID CAccessVehiData_sendFirstDataToApp
*   @paramList E_ACCESS_VEHI_DATA_T
*   @priority P2
*   @resolution_Method Equivalence Partitioning
*   @test_condition input < MAX_AVD_IDX
*   @test_Coverage_Item input < MAX_AVD_IDX
*   @test_case_ID CAccessVehiData_sendFirstDataToApp_TC001
*   @test_type functionality
*   @test_objective verify params and function called when calling sendFirstDataToApp
*   @test_precon N/A
*   @test_input eVehId = AVD_VehSpdAvgDrvn
*   @test_expected_result function runNotifyAVDtoVCA get called once with param: eVehiId = AVD_VehSpdAvgDrvn, nVehiDataSize = VEHI_AVD_FLOAT_T size, bHasValidity = true, bValidity = true
*   @test_module
*   @design_id
*/
TEST_F(CEvtHandlerFromMgrAppMainTest, CEvtHandlerFromMgrAppMain_CallAccept_TC001)
{
	EXPECT_CALL(*M_CMgrIap, AcceptNewCarPlayCall(_,_)).Times(1);

	testObj->CallAccept(NULL, 0);
}
