class MockCIapConf {
  public:
//     MOCK_METHOD1(SetIapUrlOverWifi, void(const char* strUrl));
//     MOCK_METHOD2(InitIdentification, void(E_IAP_TYPE eProjType, CinemoIAPConfig* pIapConf));
    MOCK_METHOD0(InitCinemoConfig, CinemoError());
//     MOCK_METHOD1(SetIdentificationIpod, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD1(SetIdentificationCarPlay, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD1(SetIdentificationCarLife, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD1(SetIdentificationWired, void(IAPIdentificationConfig* pConfig));
//     MOCK_METHOD1(SetIdentificationWireless, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD1(SetIdentificationBtUuid, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD1(SetIdentificationBtWcp, void(IAPIdentificationConfig* pConf));
//     MOCK_METHOD0(SetLocalParams, void());
};

MockCIapConf * M_CIapConf;

CIapConf::CIapConf(const IAP_CONF_T* pConf) 
{

}

CIapConf::~CIapConf() 
{

}

void CIapConf::SetIapUrlOverWifi(const char* strUrl) 
{
//    M_CIapConf->SetIapUrlOverWifi(strUrl);
}

void CIapConf::InitIdentification(E_IAP_TYPE eProjType, CinemoIAPConfig* pIapConf) 
{
//    M_CIapConf->InitIdentification(eProjType, pIapConf);
}

CinemoError CIapConf::InitCinemoConfig() 
{
    return M_CIapConf->InitCinemoConfig();
}

void CIapConf::SetIdentificationIpod(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationIpod(pConf);
}

void CIapConf::SetIdentificationCarPlay(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationCarPlay(pConf);
}

void CIapConf::SetIdentificationCarLife(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationCarLife(pConf);
}

void CIapConf::SetIdentificationWired(IAPIdentificationConfig* pConfig) 
{
//    M_CIapConf->SetIdentificationWired(pConfig);
}

void CIapConf::SetIdentificationWireless(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationWireless(pConf);
}

void CIapConf::SetIdentificationBtUuid(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationBtUuid(pConf);
}

void CIapConf::SetIdentificationBtWcp(IAPIdentificationConfig* pConf) 
{
//    M_CIapConf->SetIdentificationBtWcp(pConf);
}

void CIapConf::SetLocalParams() 
{
//    M_CIapConf->SetLocalParams();
}


