class MockCIap {
  public:
//     MOCK_METHOD0(run, void());
    MOCK_METHOD0(StopIap, CinemoError());
//     MOCK_METHOD1(SetLocationStatus, void(bool bLocationSvcStatus));
//     MOCK_METHOD1(SendOOBBTPairingCompletionInfo, void(bool res));
//     MOCK_METHOD0(AcceptCarPlayCallImpl, void());
//     MOCK_METHOD0(RejectCarPlayCallImpl, void());
//     MOCK_METHOD1(SetSessionInfo, void(stSessionInfo_t * pSessionInfo));
//     MOCK_METHOD1(SetSessionInfoRetry, void(stSessionInfo_t * pSessionInfo));
//     MOCK_METHOD1(SetOOBBTPairingLocalInfo, void(uint32_t pOobbtLocalInfoCod));
//     MOCK_METHOD1(SetIapType, void(E_IAP_TYPE_T eIapType));
//     MOCK_METHOD1(SetBtAddr, void(char* btAddr));
//     MOCK_METHOD1(SetWifiInfo, void(WIFI_CREDENTIAL_INFO* pWifiInfo));
//     MOCK_METHOD1(SetCancelInfo, void(bool bRequestCancel));
    MOCK_METHOD0(GetIapUrl, const char*());
//     MOCK_METHOD0(StartRuntimeLocation, void());
//     MOCK_METHOD0(StopRuntimeLocation, void());
//     MOCK_METHOD0(AcceptNewCarPlayCallImpl, void(void));
//     MOCK_METHOD0(RejectNewCarPlayCallImpl, void(void));
//     MOCK_METHOD0(IgnorCarPlayCallImpl, void(void));
//     MOCK_METHOD1(InitiateCarPlayCallImpl, void(IAP_RECENTS_ITEM_ELEMENT_T item));
//     MOCK_METHOD0(SwapCarPlayCallsImpl, void());
//     MOCK_METHOD0(MergeCarPlayCallsImpl, void());
//     MOCK_METHOD1(MuteStatusCarPlayUpdateImpl, void(bool muteStatus));
//     MOCK_METHOD0(SendCarPlayCallTimerImpl, void());
//     MOCK_METHOD0(RecentCarPlayCallHistory, void());
//     MOCK_METHOD1(RecentCarPlayCallDial, void(IAP_RECENTS_ITEM_ELEMENT_T item));
    MOCK_METHOD0(InitIap, CinemoError());
//     MOCK_METHOD0(ReleaseResources, void());
//     MOCK_METHOD1(CreateRuntime, void(CinemoIAPConfig* pIapConf));
    MOCK_METHOD0(ReleaseRuntime, CinemoError());
    MOCK_METHOD0(StartRuntime, CinemoError());
    MOCK_METHOD0(StartPowerUpdate, CinemoError());
//     MOCK_METHOD0(SendRuntimeStatus, void());
//     MOCK_METHOD0(SendRuntimeLocation, void());
//     MOCK_METHOD0(WatchVfs, void());
    MOCK_METHOD0(Open, CinemoError());
    MOCK_METHOD0(OpenVFS, CinemoError());
    MOCK_METHOD0(OpenIapCarPlay, CinemoError());
    MOCK_METHOD0(OpenIapWireless, CinemoError());
    MOCK_METHOD0(OpenIapIpod, CinemoError());
    MOCK_METHOD0(OpenIapBt, CinemoError());
    MOCK_METHOD0(OpenIapBtWCP, CinemoError());
    MOCK_METHOD0(OpenIapWired, CinemoError());
    MOCK_METHOD0(OpenIapCarLife, CinemoError());
    MOCK_METHOD0(Close, CinemoError());
//     MOCK_METHOD1(SetVehicleInfo, void(CARPLAY_VEHICLE_INFO_T* vehicleInfo));
//     MOCK_METHOD1(SetLocationInfo, void(CARPLAY_LOCATION_INFO_T* locationInfo));
//     MOCK_METHOD1(SetUTCTimeInfo, void(CARPLAY_UTC_TM_T* utcTimeInfo));
    MOCK_METHOD2(GetAppleID, CinemoError(uint8_t* devName, uint8_t* appleId));
    MOCK_METHOD1(GetAppleBtMacAddr, CinemoError(char* btMac));
    MOCK_METHOD1(GetAppleSerialNumber, CinemoError(char* serialNumber));
    MOCK_METHOD2(CheckIapType, CinemoError(bool *bDeviceIap1, uint32 *isIndexSupport));
    MOCK_METHOD1(RequestLaunchApp, CinemoError(const char* appName));
//     MOCK_METHOD2(GetMetaInfoText, void(uint8_t* metaDataInfo, CinemoAutoPtr<ICinemoUTF8> const trackMetaInfo));
//     MOCK_METHOD0(CheckWCPStatus, void());
//     MOCK_METHOD0(SendIapOpenFail, void());
//     MOCK_METHOD1(SendWcpStatusLegacyBt, void(uint32 wcpStatus));
//     MOCK_METHOD1(SendWcpStatusUnknownDev, void(uint32 wcpStatus));
//     MOCK_METHOD1(SendWcpStatusKnownDev, void(uint32 wcpStatus));
};

MockCIap * M_CIap;

CIap::CIap(const IAP_CONF_T* pConf) 
{

}

CIap::~CIap() 
{

}

void CIap::run() 
{
//    M_CIap->run();
}

CinemoError CIap::StopIap() 
{
    return M_CIap->StopIap();
}

void CIap::SetLocationStatus(bool bLocationSvcStatus) 
{
//    M_CIap->SetLocationStatus(bLocationSvcStatus);
}

void CIap::SendOOBBTPairingCompletionInfo(bool res) 
{
//    M_CIap->SendOOBBTPairingCompletionInfo(res);
}

void CIap::AcceptCarPlayCallImpl() 
{
//    M_CIap->AcceptCarPlayCallImpl();
}

void CIap::RejectCarPlayCallImpl() 
{
//    M_CIap->RejectCarPlayCallImpl();
}

void CIap::SetSessionInfo(stSessionInfo_t * pSessionInfo) 
{
//    M_CIap->SetSessionInfo(pSessionInfo);
}

void CIap::SetSessionInfoRetry(stSessionInfo_t * pSessionInfo) 
{
//    M_CIap->SetSessionInfoRetry(pSessionInfo);
}

void CIap::SetOOBBTPairingLocalInfo(uint32_t pOobbtLocalInfoCod) 
{
//    M_CIap->SetOOBBTPairingLocalInfo(pOobbtLocalInfoCod);
}

void CIap::SetIapType(E_IAP_TYPE_T eIapType) 
{
//    M_CIap->SetIapType(eIapType);
}

void CIap::SetBtAddr(char* btAddr) 
{
//    M_CIap->SetBtAddr(btAddr);
}

void CIap::SetWifiInfo(WIFI_CREDENTIAL_INFO* pWifiInfo) 
{
//    M_CIap->SetWifiInfo(pWifiInfo);
}

void CIap::SetCancelInfo(bool bRequestCancel) 
{
//    M_CIap->SetCancelInfo(bRequestCancel);
}

const char* CIap::GetIapUrl() 
{
    return M_CIap->GetIapUrl();
}

void CIap::StartRuntimeLocation() 
{
//    M_CIap->StartRuntimeLocation();
}

void CIap::StopRuntimeLocation() 
{
//    M_CIap->StopRuntimeLocation();
}

void CIap::AcceptNewCarPlayCallImpl(void) 
{
//    M_CIap->AcceptNewCarPlayCallImpl();
}

void CIap::RejectNewCarPlayCallImpl(void) 
{
//    M_CIap->RejectNewCarPlayCallImpl();
}

void CIap::IgnorCarPlayCallImpl(void) 
{
//    M_CIap->IgnorCarPlayCallImpl();
}

void CIap::InitiateCarPlayCallImpl(IAP_RECENTS_ITEM_ELEMENT_T item) 
{
//    M_CIap->InitiateCarPlayCallImpl(item);
}

void CIap::SwapCarPlayCallsImpl() 
{
//    M_CIap->SwapCarPlayCallsImpl();
}

void CIap::MergeCarPlayCallsImpl() 
{
//    M_CIap->MergeCarPlayCallsImpl();
}

void CIap::MuteStatusCarPlayUpdateImpl(bool muteStatus) 
{
//    M_CIap->MuteStatusCarPlayUpdateImpl(muteStatus);
}

void CIap::SendCarPlayCallTimerImpl() 
{
//    M_CIap->SendCarPlayCallTimerImpl();
}

void CIap::RecentCarPlayCallHistory() 
{
//    M_CIap->RecentCarPlayCallHistory();
}

void CIap::RecentCarPlayCallDial(IAP_RECENTS_ITEM_ELEMENT_T item) 
{
//    M_CIap->RecentCarPlayCallDial(item);
}

CinemoError CIap::InitIap() 
{
    return M_CIap->InitIap();
}

void CIap::ReleaseResources() 
{
//    M_CIap->ReleaseResources();
}

void CIap::CreateRuntime(CinemoIAPConfig* pIapConf) 
{
//    M_CIap->CreateRuntime(pIapConf);
}

CinemoError CIap::ReleaseRuntime() 
{
    return M_CIap->ReleaseRuntime();
}

CinemoError CIap::StartRuntime() 
{
    return M_CIap->StartRuntime();
}

CinemoError CIap::StartPowerUpdate() 
{
    return M_CIap->StartPowerUpdate();
}

void CIap::SendRuntimeStatus() 
{
//    M_CIap->SendRuntimeStatus();
}

void CIap::SendRuntimeLocation() 
{
//    M_CIap->SendRuntimeLocation();
}

void CIap::WatchVfs() 
{
//    M_CIap->WatchVfs();
}

CinemoError CIap::Open() 
{
    return M_CIap->Open();
}

CinemoError CIap::OpenVFS() 
{
    return M_CIap->OpenVFS();
}

CinemoError CIap::OpenIapCarPlay() 
{
    return M_CIap->OpenIapCarPlay();
}

CinemoError CIap::OpenIapWireless() 
{
    return M_CIap->OpenIapWireless();
}

CinemoError CIap::OpenIapIpod() 
{
    return M_CIap->OpenIapIpod();
}

CinemoError CIap::OpenIapBt() 
{
    return M_CIap->OpenIapBt();
}

CinemoError CIap::OpenIapBtWCP() 
{
    return M_CIap->OpenIapBtWCP();
}

CinemoError CIap::OpenIapWired() 
{
    return M_CIap->OpenIapWired();
}

CinemoError CIap::OpenIapCarLife() 
{
    return M_CIap->OpenIapCarLife();
}

CinemoError CIap::Close() 
{
    return M_CIap->Close();
}

void CIap::SetVehicleInfo(CARPLAY_VEHICLE_INFO_T* vehicleInfo) 
{
//    M_CIap->SetVehicleInfo(vehicleInfo);
}

void CIap::SetLocationInfo(CARPLAY_LOCATION_INFO_T* locationInfo) 
{
//    M_CIap->SetLocationInfo(locationInfo);
}

void CIap::SetUTCTimeInfo(CARPLAY_UTC_TM_T* utcTimeInfo) 
{
//    M_CIap->SetUTCTimeInfo(utcTimeInfo);
}

CinemoError CIap::GetAppleID(uint8_t* devName, uint8_t* appleId) 
{
    return M_CIap->GetAppleID(devName, appleId);
}

CinemoError CIap::GetAppleBtMacAddr(char* btMac) 
{
    return M_CIap->GetAppleBtMacAddr(btMac);
}

CinemoError CIap::GetAppleSerialNumber(char* serialNumber) 
{
    return M_CIap->GetAppleSerialNumber(serialNumber);
}

CinemoError CIap::CheckIapType(bool *bDeviceIap1, uint32 *isIndexSupport) 
{
    return M_CIap->CheckIapType(bDeviceIap1, isIndexSupport);
}

CinemoError CIap::RequestLaunchApp(const char* appName) 
{
    return M_CIap->RequestLaunchApp(appName);
}

void CIap::GetMetaInfoText(uint8_t* metaDataInfo, CinemoAutoPtr<ICinemoUTF8> const trackMetaInfo) 
{
//    M_CIap->GetMetaInfoText(metaDataInfo, trackMetaInfo);
}

void CIap::CheckWCPStatus() 
{
//    M_CIap->CheckWCPStatus();
}

void CIap::SendIapOpenFail() 
{
//    M_CIap->SendIapOpenFail();
}

void CIap::SendWcpStatusLegacyBt(uint32 wcpStatus) 
{
//    M_CIap->SendWcpStatusLegacyBt(wcpStatus);
}

void CIap::SendWcpStatusUnknownDev(uint32 wcpStatus) 
{
//    M_CIap->SendWcpStatusUnknownDev(wcpStatus);
}

void CIap::SendWcpStatusKnownDev(uint32 wcpStatus) 
{
//    M_CIap->SendWcpStatusKnownDev(wcpStatus);
}


