class MockCCinemoConfig {
  public:
//     MOCK_METHOD0(EnableCinemoLog, void());
//     MOCK_METHOD0(DisableCinemoLog, void());
//     MOCK_METHOD2(PrintCinemoLog, void(void * puser, const CinemoLogItem& logitem));
    MOCK_METHOD1(SetAppleAuth, CinemoError(bool init));
    MOCK_METHOD0(GetAuthDataValid, bool());
    MOCK_METHOD0(InitConfig, CinemoError());
    MOCK_METHOD0(ReleaseConfig, CinemoError());
//     MOCK_METHOD0(InitCinemoLog, void());
};

MockCCinemoConfig * M_CCinemoConfig;

CCinemoConfig::CCinemoConfig() 
{

}

CCinemoConfig::~CCinemoConfig() 
{

}

void CCinemoConfig::EnableCinemoLog() 
{
//    M_CCinemoConfig->EnableCinemoLog();
}

void CCinemoConfig::DisableCinemoLog() 
{
//    M_CCinemoConfig->DisableCinemoLog();
}

void CCinemoConfig::PrintCinemoLog(void * puser, const CinemoLogItem& logitem) 
{
//    M_CCinemoConfig->PrintCinemoLog();
}

CinemoError CCinemoConfig::SetAppleAuth(bool init) 
{
    return M_CCinemoConfig->SetAppleAuth(init);
}

bool CCinemoConfig::GetAuthDataValid() 
{
    return M_CCinemoConfig->GetAuthDataValid();
}

CinemoError CCinemoConfig::InitConfig() 
{
    return M_CCinemoConfig->InitConfig();
}

CinemoError CCinemoConfig::ReleaseConfig() 
{
    return M_CCinemoConfig->ReleaseConfig();
}

void CCinemoConfig::InitCinemoLog() 
{
//    M_CCinemoConfig->InitCinemoLog();
}


