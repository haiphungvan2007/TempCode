class MockCEvtHandlerFromMgrWifi {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrWifi * M_CEvtHandlerFromMgrWifi;

void CEvtHandlerFromMgrWifi::init() 
{
//    M_CEvtHandlerFromMgrWifi->init();
}


