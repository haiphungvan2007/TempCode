class MockCEvtHandlerFromMgrIAP {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrIAP * M_CEvtHandlerFromMgrIAP;

void CEvtHandlerFromMgrIAP::init() 
{
//    M_CEvtHandlerFromMgrIAP->init();
}


