class MockCEvtHandlerFromMgrSys {
};

MockCEvtHandlerFromMgrSys * M_CEvtHandlerFromMgrSys;

