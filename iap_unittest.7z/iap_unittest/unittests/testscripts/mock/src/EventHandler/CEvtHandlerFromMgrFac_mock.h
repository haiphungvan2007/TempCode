class MockCEvtHandlerFromMgrFac {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrFac * M_CEvtHandlerFromMgrFac;

void CEvtHandlerFromMgrFac::init() 
{
//    M_CEvtHandlerFromMgrFac->init();
}


