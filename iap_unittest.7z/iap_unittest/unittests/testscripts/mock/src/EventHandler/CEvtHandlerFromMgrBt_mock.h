class MockCEvtHandlerFromMgrBt {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrBt * M_CEvtHandlerFromMgrBt;

void CEvtHandlerFromMgrBt::init() 
{
//    M_CEvtHandlerFromMgrBt->init();
}


