class MockCEvtHandlerFromMgrCarPlay {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrCarPlay * M_CEvtHandlerFromMgrCarPlay;

void CEvtHandlerFromMgrCarPlay::init() 
{
//    M_CEvtHandlerFromMgrCarPlay->init();
}


