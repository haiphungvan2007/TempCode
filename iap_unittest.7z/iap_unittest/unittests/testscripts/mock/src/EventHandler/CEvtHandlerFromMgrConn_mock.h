class MockCEvtHandlerFromMgrConn {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrConn * M_CEvtHandlerFromMgrConn;

void CEvtHandlerFromMgrConn::init() 
{
//    M_CEvtHandlerFromMgrConn->init();
}


