class MockCEvtHandlerFromMgrTsk {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrTsk * M_CEvtHandlerFromMgrTsk;

void CEvtHandlerFromMgrTsk::init() 
{
//    M_CEvtHandlerFromMgrTsk->init();
}


