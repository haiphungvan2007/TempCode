class MockCEvtHandlerFromMgrVip {
  public:
    MOCK_METHOD0(Load, m_pCal.());
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrVip * M_CEvtHandlerFromMgrVip;

m_pCal. CEvtHandlerFromMgrVip::Load() 
{
    return M_CEvtHandlerFromMgrVip->Load();
}

void CEvtHandlerFromMgrVip::init() 
{
//    M_CEvtHandlerFromMgrVip->init();
}


