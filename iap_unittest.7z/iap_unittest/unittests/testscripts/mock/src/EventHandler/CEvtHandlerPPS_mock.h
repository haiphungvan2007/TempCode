class MockCEvtHandlerPPS {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerPPS * M_CEvtHandlerPPS;

void CEvtHandlerPPS::init() 
{
//    M_CEvtHandlerPPS->init();
}


