class MockCEvtHandlerFromMgrMcm {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrMcm * M_CEvtHandlerFromMgrMcm;

void CEvtHandlerFromMgrMcm::init() 
{
//    M_CEvtHandlerFromMgrMcm->init();
}


