class MockCEvtHandlerFromMgrAppMain {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerFromMgrAppMain * M_CEvtHandlerFromMgrAppMain;

void CEvtHandlerFromMgrAppMain::init() 
{
//    M_CEvtHandlerFromMgrAppMain->init();
}


