class MockCEvtHandlerTime {
  public:
//     MOCK_METHOD0(init, void());
};

MockCEvtHandlerTime * M_CEvtHandlerTime;

void CEvtHandlerTime::init() 
{
//    M_CEvtHandlerTime->init();
}


