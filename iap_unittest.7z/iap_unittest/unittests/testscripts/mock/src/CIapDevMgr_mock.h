class MockCIapDevMgr {
  public:
    MOCK_METHOD2(CreateIap, CIap*(IAP_CONF_T* pConf, char* devname));
//     MOCK_METHOD1(RemoveIap, void(const char* devname));
    MOCK_METHOD1(SearchIap, CIap*(const char* devname));
    MOCK_METHOD0(GetCountIap, unsigned long());
//     MOCK_METHOD2(AddDevice, void(const char* uuid, char* devname));
//     MOCK_METHOD1(RemoveDevice, void(const char* uuid));
    MOCK_METHOD1(SearchDevice, std::string(const char* uuid));
    MOCK_METHOD1(CheckIap, bool(std::string devname));
    MOCK_METHOD1(CheckDevice, bool(std::string uuid));
    MOCK_METHOD1(CheckTimer, bool(const int timer));
};

MockCIapDevMgr * M_CIapDevMgr;

CIapDevMgr::CIapDevMgr() 
{

}

CIapDevMgr::~CIapDevMgr() 
{

}

CIap* CIapDevMgr::CreateIap(IAP_CONF_T* pConf, char* devname) 
{
    return M_CIapDevMgr->CreateIap(pConf, devname);
}

void CIapDevMgr::RemoveIap(const char* devname) 
{
//    M_CIapDevMgr->RemoveIap(devname);
}

CIap* CIapDevMgr::SearchIap(const char* devname) 
{
    return M_CIapDevMgr->SearchIap(devname);
}

unsigned long CIapDevMgr::GetCountIap() 
{
    return M_CIapDevMgr->GetCountIap();
}

void CIapDevMgr::AddDevice(const char* uuid, char* devname) 
{
//    M_CIapDevMgr->AddDevice(uuid, devname);
}

void CIapDevMgr::RemoveDevice(const char* uuid) 
{
//    M_CIapDevMgr->RemoveDevice(uuid);
}

std::string CIapDevMgr::SearchDevice(const char* uuid) 
{
    return M_CIapDevMgr->SearchDevice(uuid);
}

bool CIapDevMgr::CheckIap(std::string devname) 
{
    return M_CIapDevMgr->CheckIap(devname);
}

bool CIapDevMgr::CheckDevice(std::string uuid) 
{
    return M_CIapDevMgr->CheckDevice(uuid);
}

bool CIapDevMgr::CheckTimer(const int timer) 
{
    return M_CIapDevMgr->CheckTimer(timer);
}


