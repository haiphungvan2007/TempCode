class MockRuntimeState {
};

MockRuntimeState * M_RuntimeState;

