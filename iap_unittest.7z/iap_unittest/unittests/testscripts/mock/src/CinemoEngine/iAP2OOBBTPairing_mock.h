class MockCiAP2OOBBTPairing {
  public:
    MOCK_METHOD0(StartOOBBTPairing, CinemoError());
    MOCK_METHOD2(OOBBTPairingLinkKeyInformation, CinemoError(CinemoIAP2Blob linkKey, CinemoIAP2Blob appleDevMacAddr));
    MOCK_METHOD1(SendOOBBTPairingCompletionInfo, CinemoError(bool res));
    MOCK_METHOD0(StopOOBBTPairing, CinemoError());
};

MockCiAP2OOBBTPairing * M_CiAP2OOBBTPairing;

CiAP2OOBBTPairing::CiAP2OOBBTPairing(CinemoAutoPtr<ICinemoIAP> &piap, OOBBT_LOCAL_INFO_T* pOobbt_info) 
{

}

CiAP2OOBBTPairing::~CiAP2OOBBTPairing() 
{

}

CinemoError CiAP2OOBBTPairing::StartOOBBTPairing() 
{
    return M_CiAP2OOBBTPairing->StartOOBBTPairing();
}

CinemoError CiAP2OOBBTPairing::OOBBTPairingLinkKeyInformation(CinemoIAP2Blob linkKey, CinemoIAP2Blob appleDevMacAddr) 
{
    return M_CiAP2OOBBTPairing->OOBBTPairingLinkKeyInformation(linkKey, appleDevMacAddr);
}

CinemoError CiAP2OOBBTPairing::SendOOBBTPairingCompletionInfo(bool res) 
{
    return M_CiAP2OOBBTPairing->SendOOBBTPairingCompletionInfo(res);
}

CinemoError CiAP2OOBBTPairing::StopOOBBTPairing() 
{
    return M_CiAP2OOBBTPairing->StopOOBBTPairing();
}


