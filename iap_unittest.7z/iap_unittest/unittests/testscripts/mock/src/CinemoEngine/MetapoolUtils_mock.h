namespace CINEMO_SUPPORT {

class MockMetapoolUtils {
  public:
};

MockMetapoolUtils * M_MetapoolUtils;

}  // namespace CINEMO_SUPPORT

