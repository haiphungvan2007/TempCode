class MockCVIPInfoData {
  public:
//     MOCK_METHOD0(MAKE_SINGLETON, void(CVIPInfoData, Mutex));
    MOCK_METHOD2(setVINInfo, int(const char* data, int size));
    MOCK_METHOD2(setSMRFInfo, int(char* data, int size));
//     MOCK_METHOD1(setOnStarSvcOn, void(bool isNonConType));
    MOCK_METHOD0(OnStarSvcOn, bool());
    MOCK_METHOD0(getHashedVin, unsigned char*());
    MOCK_METHOD0(getHashedVinSize, int());
    MOCK_METHOD0(getSMRFInfo, VIP_NON_CON_SMRF_INFO*());
    MOCK_METHOD0(getSMRFInfoSize, int());
};

MockCVIPInfoData * M_CVIPInfoData;

void CVIPInfoData::MAKE_SINGLETON(CVIPInfoData, Mutex) 
{
//    M_CVIPInfoData->MAKE_SINGLETON(CVIPInfoData, Mutex);
}

int CVIPInfoData::setVINInfo(const char* data, int size) 
{
    return M_CVIPInfoData->setVINInfo(data, size);
}

int CVIPInfoData::setSMRFInfo(char* data, int size) 
{
    return M_CVIPInfoData->setSMRFInfo(data, size);
}

void CVIPInfoData::setOnStarSvcOn(bool isNonConType) 
{
//    M_CVIPInfoData->setOnStarSvcOn(isNonConType);
}

bool CVIPInfoData::OnStarSvcOn() 
{
    return M_CVIPInfoData->OnStarSvcOn();
}

unsigned char* CVIPInfoData::getHashedVin() 
{
    return M_CVIPInfoData->getHashedVin();
}

int CVIPInfoData::getHashedVinSize() 
{
    return M_CVIPInfoData->getHashedVinSize();
}

VIP_NON_CON_SMRF_INFO* CVIPInfoData::getSMRFInfo() 
{
    return M_CVIPInfoData->getSMRFInfo();
}

int CVIPInfoData::getSMRFInfoSize() 
{
    return M_CVIPInfoData->getSMRFInfoSize();
}


