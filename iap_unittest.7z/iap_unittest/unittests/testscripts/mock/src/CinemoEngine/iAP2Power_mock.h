class MockCiAP2PowerUpdates {
  public:
    MOCK_METHOD0(startPowerUpdate, CinemoError());
    MOCK_METHOD0(sendPowerUpdate, CinemoError());
    MOCK_METHOD0(stopPowerUpdate, CinemoError());
    MOCK_METHOD1(PowerUpdate, CinemoError(const CinemoIAPPowerUpdate& update));
};

MockCiAP2PowerUpdates * M_CiAP2PowerUpdates;

CiAP2PowerUpdates::CiAP2PowerUpdates(CinemoAutoPtr<ICinemoIAP> &piap, stDeviceFuncParam* pparam) 
{

}

CiAP2PowerUpdates::~CiAP2PowerUpdates() 
{

}

CinemoError CiAP2PowerUpdates::startPowerUpdate() 
{
    return M_CiAP2PowerUpdates->startPowerUpdate();
}

CinemoError CiAP2PowerUpdates::sendPowerUpdate() 
{
    return M_CiAP2PowerUpdates->sendPowerUpdate();
}

CinemoError CiAP2PowerUpdates::stopPowerUpdate() 
{
    return M_CiAP2PowerUpdates->stopPowerUpdate();
}

CinemoError CiAP2PowerUpdates::PowerUpdate(const CinemoIAPPowerUpdate& update) 
{
    return M_CiAP2PowerUpdates->PowerUpdate(update);
}


