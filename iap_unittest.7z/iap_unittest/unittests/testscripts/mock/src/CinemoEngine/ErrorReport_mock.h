namespace CINEMO_SUPPORT {

class MockIErrorReport {
  public:
//     MOCK_CONST_METHOD2(Error, void(CinemoError hr, char const * msg));
};

MockIErrorReport * M_IErrorReport;

class MockThrowingErrorReporter {
  public:
//     MOCK_CONST_METHOD2(Error, void(CinemoError hr, char const * msg));
};

MockThrowingErrorReporter * M_ThrowingErrorReporter;

void IErrorReport::Error(CinemoError hr, char const * msg) const
{
//    M_IErrorReport->Error(hr, msg);
}


ThrowingErrorReporter::ThrowingErrorReporter() 
{

}

ThrowingErrorReporter::~ThrowingErrorReporter() 
{

}

void ThrowingErrorReporter::Error(CinemoError hr, char const * msg) const
{
//    M_ThrowingErrorReporter->Error(hr, msg);
}


}  // namespace CINEMO_SUPPORT

