class MockTlsWrapper {
  public:
//     MOCK_METHOD0(MAKE_SINGLETON, void(TlsWrapper, Mutex));
//     MOCK_METHOD0(deinit, void());
};

MockTlsWrapper * M_TlsWrapper;

class MockCiAP2EAPAnnounce {
  public:
//     MOCK_METHOD2(EAPSessionInitiated, void(uint16 session_id, uint8 protocol_id));
//     MOCK_METHOD1(EndEAPSession, void(uint16 session_id));
//     MOCK_METHOD2(EAPPacketArrived, void(uint16 session_id, size_t numPackets));
//     MOCK_METHOD2(EAPPacketArrived, void(uint16 session_id, uint32 numPackets));
    MOCK_METHOD2(EAPSessionSend, int(const void * payload, int payload_bytes));
    MOCK_METHOD0(EAPSessionStatus, int());
    MOCK_METHOD0(init, int());
//     MOCK_METHOD0(clearTLS, void());
//     MOCK_METHOD0(shutdown, void());
    MOCK_METHOD3(OnEAPDataAvailable, CinemoError(uint16 session_id, const uchar * pdata, int data_len));
};

MockCiAP2EAPAnnounce * M_CiAP2EAPAnnounce;

void TlsWrapper::MAKE_SINGLETON(TlsWrapper, Mutex) 
{
//    M_TlsWrapper->MAKE_SINGLETON(TlsWrapper, Mutex);
}

void TlsWrapper::deinit() 
{
//    M_TlsWrapper->deinit();
}


CiAP2EAPAnnounce::CiAP2EAPAnnounce(CinemoAutoPtr<ICinemoIAP> &piap) 
{

}

CiAP2EAPAnnounce::~CiAP2EAPAnnounce() 
{

}

void CiAP2EAPAnnounce::EAPSessionInitiated(uint16 session_id, uint8 protocol_id) 
{
//    M_CiAP2EAPAnnounce->EAPSessionInitiated(session_id, protocol_id);
}

void CiAP2EAPAnnounce::EndEAPSession(uint16 session_id) 
{
//    M_CiAP2EAPAnnounce->EndEAPSession(session_id);
}

void CiAP2EAPAnnounce::EAPPacketArrived(uint16 session_id, size_t numPackets) 
{
//    M_CiAP2EAPAnnounce->EAPPacketArrived(session_id, numPackets);
}

void CiAP2EAPAnnounce::EAPPacketArrived(uint16 session_id, uint32 numPackets) 
{
//    M_CiAP2EAPAnnounce->EAPPacketArrived(session_id, numPackets);
}

int CiAP2EAPAnnounce::EAPSessionSend(const void * payload, int payload_bytes) 
{
    return M_CiAP2EAPAnnounce->EAPSessionSend(payload, payload_bytes);
}

int CiAP2EAPAnnounce::EAPSessionStatus() 
{
    return M_CiAP2EAPAnnounce->EAPSessionStatus();
}

int CiAP2EAPAnnounce::init() 
{
    return M_CiAP2EAPAnnounce->init();
}

void CiAP2EAPAnnounce::clearTLS() 
{
//    M_CiAP2EAPAnnounce->clearTLS();
}

void CiAP2EAPAnnounce::shutdown() 
{
//    M_CiAP2EAPAnnounce->shutdown();
}

CinemoError CiAP2EAPAnnounce::OnEAPDataAvailable(uint16 session_id, const uchar * pdata, int data_len) 
{
    return M_CiAP2EAPAnnounce->OnEAPDataAvailable(session_id, pdata, data_len);
}


