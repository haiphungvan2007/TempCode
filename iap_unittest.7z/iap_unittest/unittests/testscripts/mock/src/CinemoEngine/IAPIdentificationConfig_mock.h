namespace CINEMO_SUPPORT {

class MockIAPIdentificationConfig {
  public:
    MOCK_METHOD1(adjust_rejected, bool(CinemoIAP2IdentificationRejected const & rejected));
    MOCK_METHOD3(set_accessory_names, IAPIdentificationConfig&(char const * name, char const * model, char const * manufacturer));
    MOCK_METHOD1(set_accessory_serial, IAPIdentificationConfig&(char const * serial));
    MOCK_METHOD3(set_accessory_firmware_version, IAPIdentificationConfig&(uchar major, uchar minor, uchar build));
    MOCK_METHOD3(set_accessory_hardware_version, IAPIdentificationConfig&(uchar major, uchar minor, uchar build));
    MOCK_METHOD2(set_sample_rates, IAPIdentificationConfig&(uint32 rates[], size_t rateCnt));
    MOCK_METHOD0(add_general_entries, IAPIdentificationConfig&());
    MOCK_METHOD1(add_accessory_product_plan_UUID, IAPIdentificationConfig&(char const * uuid));
    MOCK_METHOD1(add_accessory_firmware_version_IAP2, IAPIdentificationConfig&(char const * version));
    MOCK_METHOD1(add_accessory_hardware_version_IAP2, IAPIdentificationConfig&(char const * version));
    MOCK_METHOD0(add_iAP1_minimal_entries, IAPIdentificationConfig&());
    MOCK_METHOD0(add_iAP1_normal_entries, IAPIdentificationConfig&());
    MOCK_METHOD1(add_iAP1_config_flags, IAPIdentificationConfig&(uint32 flags));
    MOCK_METHOD1(add_iAP2_config_flags, IAPIdentificationConfig&(uint32 flags));
    MOCK_METHOD3(add_iAP2_language_info, IAPIdentificationConfig&(char const * current, char const * supported[], size_t numSupported));
    MOCK_METHOD2(add_iAP2_language_info, IAPIdentificationConfig&(std::string const & current, std::vector<std::string> const & supported));
    MOCK_METHOD0(add_media_lib_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_resume_default_playback_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_basic_playlist_select_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_native_playlist_select_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_now_playing_seek_select_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_now_playing_info_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_power_status_support, IAPIdentificationConfig&());
    MOCK_METHOD1(add_power_providing_support, IAPIdentificationConfig&(int mA));
    MOCK_METHOD3(add_USB_device_mode_transport_component, IAPIdentificationConfig&(int , const *, bool ));
    MOCK_METHOD0(add_USB_device_audio_support, IAPIdentificationConfig&());
    MOCK_METHOD3(add_USB_host_mode_transport_component, IAPIdentificationConfig&(int , const *, bool ));
    MOCK_METHOD5(add_BT_transport_component, IAPIdentificationConfig&(int , const *, bool , uint8 *, size_t ));
    MOCK_METHOD3(add_WiFi_transport_component, IAPIdentificationConfig&(int , const *, bool ));
    MOCK_METHOD1(del_WiFi_transport_component, IAPIdentificationConfig&(int componentId));
    MOCK_METHOD7(add_iAP2_HID_component, IAPIdentificationConfig&(int componentId, char const * name, int compFn, uint16 vid, uint16 pid, uchar const descr[], size_t descrSize));
    MOCK_METHOD7(add_USB_host_mode_HID_component, IAPIdentificationConfig&(int componentId, char const * name, int compFn, int USB_transCompId, int USB_if_num, uchar const descr[], size_t descrSize));
    MOCK_METHOD6(add_BT_HID_component, IAPIdentificationConfig&(int componentId, char const * name, int compFn, int BT_transCompId, uchar const descr[], size_t descrSize));
    MOCK_METHOD3(add_location_support, IAPIdentificationConfig&(int componentId, char const * name, uint32 loc_flags));
    MOCK_METHOD0(add_communications_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_communications_support_custom, IAPIdentificationConfig&());
    MOCK_METHOD4(add_communications_support, IAPIdentificationConfig&(bool com_updates, bool list_updates, bool call_state, bool call_control));
    MOCK_METHOD5(add_vehicle_info_support, IAPIdentificationConfig&(int veh_comp_id, char const * info_name, char const * disp_name, Engine engines[], size_t engines_count));
    MOCK_METHOD5(add_vehicle_info_support, IAPIdentificationConfig&(int veh_comp_id, char const * info_name, char const * disp_name, CINEMO_IAP_VEHICLE_INFO_ENGINE_TYPE engine_type[], size_t engine_type_count));
    MOCK_METHOD3(add_vehicle_status_support, IAPIdentificationConfig&(int veh_comp_id, char const * status_name, uint32 status_flags));
    MOCK_METHOD2(add_destination_info_support, IAPIdentificationConfig&(int veh_comp_id, char const * maps_disp_name));
    MOCK_METHOD0(add_route_guidance_support, IAPIdentificationConfig&());
    MOCK_METHOD8(add_route_guidance_component, IAPIdentificationConfig&(int componentId, char const * name, uint16 max_current_road_name_length, uint16 max_destination_name_length, uint16 max_after_maneuver_road_name_length, uint16 max_maneuver_description_length, uint16 max_guidance_maneuver_capacity, uint16 max_lane_guidance_storage_capacity));
    MOCK_METHOD4(add_route_guidance_support, IAPIdentificationConfig&(int , const *, uint16 , uint16 ));
    MOCK_METHOD0(add_wifi_information_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_app_launch_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_app_discovery_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_BT_connection_status_support, IAPIdentificationConfig&());
    MOCK_METHOD2(add_eap_protocols, IAPIdentificationConfig&(EA_Protocol eap[], size_t count));
    MOCK_METHOD1(add_app_match_team_id, IAPIdentificationConfig&(char const * team_id));
    MOCK_METHOD0(add_voice_over_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_assistive_touch_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_out_of_band_bluetooth_pairing_support, IAPIdentificationConfig&());
    MOCK_METHOD0(add_bluetooth_pairing_support, IAPIdentificationConfig&());
};

MockIAPIdentificationConfig * M_IAPIdentificationConfig;

IAPIdentificationConfig::IAPIdentificationConfig(IErrorReport err_reporter) 
{

}

IAPIdentificationConfig::~IAPIdentificationConfig() 
{

}

bool IAPIdentificationConfig::adjust_rejected(CinemoIAP2IdentificationRejected const & rejected) 
{
    return M_IAPIdentificationConfig->adjust_rejected(rejected);
}

IAPIdentificationConfig& IAPIdentificationConfig::set_accessory_names(char const * name, char const * model, char const * manufacturer) 
{
    return M_IAPIdentificationConfig->set_accessory_names(name, model, manufacturer);
}

IAPIdentificationConfig& IAPIdentificationConfig::set_accessory_serial(char const * serial) 
{
    return M_IAPIdentificationConfig->set_accessory_serial(serial);
}

IAPIdentificationConfig& IAPIdentificationConfig::set_accessory_firmware_version(uchar major, uchar minor, uchar build) 
{
    return M_IAPIdentificationConfig->set_accessory_firmware_version(major, minor, build);
}

IAPIdentificationConfig& IAPIdentificationConfig::set_accessory_hardware_version(uchar major, uchar minor, uchar build) 
{
    return M_IAPIdentificationConfig->set_accessory_hardware_version(major, minor, build);
}

IAPIdentificationConfig& IAPIdentificationConfig::set_sample_rates(uint32 rates[], size_t rateCnt) 
{
    return M_IAPIdentificationConfig->set_sample_rates(rates, rateCnt);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_general_entries() 
{
    return M_IAPIdentificationConfig->add_general_entries();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_accessory_product_plan_UUID(char const * uuid) 
{
    return M_IAPIdentificationConfig->add_accessory_product_plan_UUID(uuid);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_accessory_firmware_version_IAP2(char const * version) 
{
    return M_IAPIdentificationConfig->add_accessory_firmware_version_IAP2(version);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_accessory_hardware_version_IAP2(char const * version) 
{
    return M_IAPIdentificationConfig->add_accessory_hardware_version_IAP2(version);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP1_minimal_entries() 
{
    return M_IAPIdentificationConfig->add_iAP1_minimal_entries();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP1_normal_entries() 
{
    return M_IAPIdentificationConfig->add_iAP1_normal_entries();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP1_config_flags(uint32 flags) 
{
    return M_IAPIdentificationConfig->add_iAP1_config_flags(flags);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP2_config_flags(uint32 flags) 
{
    return M_IAPIdentificationConfig->add_iAP2_config_flags(flags);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP2_language_info(char const * current, char const * supported[], size_t numSupported) 
{
    return M_IAPIdentificationConfig->add_iAP2_language_info(current, supported, numSupported);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP2_language_info(std::string const & current, std::vector<std::string> const & supported) 
{
    return M_IAPIdentificationConfig->add_iAP2_language_info(current, supported);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_media_lib_support() 
{
    return M_IAPIdentificationConfig->add_media_lib_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_resume_default_playback_support() 
{
    return M_IAPIdentificationConfig->add_resume_default_playback_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_basic_playlist_select_support() 
{
    return M_IAPIdentificationConfig->add_basic_playlist_select_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_native_playlist_select_support() 
{
    return M_IAPIdentificationConfig->add_native_playlist_select_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_now_playing_seek_select_support() 
{
    return M_IAPIdentificationConfig->add_now_playing_seek_select_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_now_playing_info_support() 
{
    return M_IAPIdentificationConfig->add_now_playing_info_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_power_status_support() 
{
    return M_IAPIdentificationConfig->add_power_status_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_power_providing_support(int mA) 
{
    return M_IAPIdentificationConfig->add_power_providing_support(mA);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_USB_device_mode_transport_component(int componentId, const *name, bool support_iap2) 
{
    return M_IAPIdentificationConfig->add_USB_device_mode_transport_component(componentId, name, support_iap2);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_USB_device_audio_support() 
{
    return M_IAPIdentificationConfig->add_USB_device_audio_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_USB_host_mode_transport_component(int componentId, const *name, bool support_carplay) 
{
    return M_IAPIdentificationConfig->add_USB_host_mode_transport_component(componentId, name, support_carplay);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_BT_transport_component(int componentId, const *name, bool support_iap2, uint8 *macBytes, size_t macSize) 
{
    return M_IAPIdentificationConfig->add_BT_transport_component(componentId, name, support_iap2, macBytes, macSize);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_WiFi_transport_component(int componentId, const *name, bool support_iap2) 
{
    return M_IAPIdentificationConfig->add_WiFi_transport_component(componentId, name, support_iap2);
}

IAPIdentificationConfig& IAPIdentificationConfig::del_WiFi_transport_component(int componentId) 
{
    return M_IAPIdentificationConfig->del_WiFi_transport_component(componentId);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_iAP2_HID_component(int componentId, char const * name, int compFn, uint16 vid, uint16 pid, uchar const descr[], size_t descrSize) 
{
    return M_IAPIdentificationConfig->add_iAP2_HID_component(componentId, name, compFn, vid, pid, descr, descrSize);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_USB_host_mode_HID_component(int componentId, char const * name, int compFn, int USB_transCompId, int USB_if_num, uchar const descr[], size_t descrSize) 
{
    return M_IAPIdentificationConfig->add_USB_host_mode_HID_component(componentId, name, compFn, USB_transCompId, USB_if_num, descr, descrSize);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_BT_HID_component(int componentId, char const * name, int compFn, int BT_transCompId, uchar const descr[], size_t descrSize) 
{
    return M_IAPIdentificationConfig->add_BT_HID_component(componentId, name, compFn, BT_transCompId, descr, descrSize);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_location_support(int componentId, char const * name, uint32 loc_flags) 
{
    return M_IAPIdentificationConfig->add_location_support(componentId, name, loc_flags);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_communications_support() 
{
    return M_IAPIdentificationConfig->add_communications_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_communications_support_custom() 
{
    return M_IAPIdentificationConfig->add_communications_support_custom();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_communications_support(bool com_updates, bool list_updates, bool call_state, bool call_control) 
{
    return M_IAPIdentificationConfig->add_communications_support(com_updates, list_updates, call_state, call_control);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_vehicle_info_support(int veh_comp_id, char const * info_name, char const * disp_name, Engine engines[], size_t engines_count) 
{
    return M_IAPIdentificationConfig->add_vehicle_info_support(veh_comp_id, info_name, disp_name, engines, engines_count);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_vehicle_info_support(int veh_comp_id, char const * info_name, char const * disp_name, CINEMO_IAP_VEHICLE_INFO_ENGINE_TYPE engine_type[], size_t engine_type_count) 
{
    return M_IAPIdentificationConfig->add_vehicle_info_support(veh_comp_id, info_name, disp_name, engine_type, engine_type_count);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_vehicle_status_support(int veh_comp_id, char const * status_name, uint32 status_flags) 
{
    return M_IAPIdentificationConfig->add_vehicle_status_support(veh_comp_id, status_name, status_flags);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_destination_info_support(int veh_comp_id, char const * maps_disp_name) 
{
    return M_IAPIdentificationConfig->add_destination_info_support(veh_comp_id, maps_disp_name);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_route_guidance_support() 
{
    return M_IAPIdentificationConfig->add_route_guidance_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_route_guidance_component(int componentId, char const * name, uint16 max_current_road_name_length, uint16 max_destination_name_length, uint16 max_after_maneuver_road_name_length, uint16 max_maneuver_description_length, uint16 max_guidance_maneuver_capacity, uint16 max_lane_guidance_storage_capacity) 
{
    return M_IAPIdentificationConfig->add_route_guidance_component(componentId, name, max_current_road_name_length, max_destination_name_length, max_after_maneuver_road_name_length, max_maneuver_description_length, max_guidance_maneuver_capacity, max_lane_guidance_storage_capacity);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_route_guidance_support(int componentId, const *name, uint16 maneuver_capacity, uint16 display_capacity) 
{
    return M_IAPIdentificationConfig->add_route_guidance_support(componentId, name, maneuver_capacity, display_capacity);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_wifi_information_support() 
{
    return M_IAPIdentificationConfig->add_wifi_information_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_app_launch_support() 
{
    return M_IAPIdentificationConfig->add_app_launch_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_app_discovery_support() 
{
    return M_IAPIdentificationConfig->add_app_discovery_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_BT_connection_status_support() 
{
    return M_IAPIdentificationConfig->add_BT_connection_status_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_eap_protocols(EA_Protocol eap[], size_t count) 
{
    return M_IAPIdentificationConfig->add_eap_protocols(eap, count);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_app_match_team_id(char const * team_id) 
{
    return M_IAPIdentificationConfig->add_app_match_team_id(team_id);
}

IAPIdentificationConfig& IAPIdentificationConfig::add_voice_over_support() 
{
    return M_IAPIdentificationConfig->add_voice_over_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_assistive_touch_support() 
{
    return M_IAPIdentificationConfig->add_assistive_touch_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_out_of_band_bluetooth_pairing_support() 
{
    return M_IAPIdentificationConfig->add_out_of_band_bluetooth_pairing_support();
}

IAPIdentificationConfig& IAPIdentificationConfig::add_bluetooth_pairing_support() 
{
    return M_IAPIdentificationConfig->add_bluetooth_pairing_support();
}


}  // namespace CINEMO_SUPPORT

