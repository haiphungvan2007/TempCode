class MockCiAP2Telephony {
  public:
    MOCK_METHOD0(startTelephonyUpdate, CinemoError());
    MOCK_METHOD0(stopTelephonyUpdate, CinemoError());
    MOCK_METHOD0(AcceptCallImpl, CinemoError());
    MOCK_METHOD0(EndCallImpl, CinemoError());
//     MOCK_METHOD2(RegisterTelephonyCallbk, void(CBFUNC_iAP2 func, void* ctx));
    MOCK_METHOD0(AcceptNewCallImpl, CinemoError(void));
    MOCK_METHOD0(EndNewCallImpl, CinemoError(void));
    MOCK_METHOD0(IgonrCallImpl, CinemoError(void));
    MOCK_METHOD1(InitiateCallImpl, CinemoError(IAP_RECENTS_ITEM_ELEMENT_T item));
    MOCK_METHOD0(SwapCallsImpl, CinemoError());
    MOCK_METHOD0(MergeCallsImpl, CinemoError());
    MOCK_METHOD1(MuteStatusUpdateImpl, CinemoError(bool muteStatus));
    MOCK_METHOD0(SearchFocusCallPosition, int());
    MOCK_METHOD1(CallStateUpdate, CinemoError(const CinemoIAPCommunicationsCallState& update));
    MOCK_METHOD1(CommunicationsUpdate, CinemoError(const CinemoIAPCommunicationsUpdate& update));
    MOCK_METHOD1(ListUpdate, CinemoError(const CinemoIAPCommunicationsListUpdate& update));
    MOCK_METHOD1(CallStatusToString, const char*(E_CALL_STATUS_T status));
    MOCK_METHOD1(CallDirectionToString, const char*(E_CALL_DIRECTION_T direction));
//     MOCK_METHOD3(ParseUtf8String, void(char* outStr, const char* inStr, size_t length));
//     MOCK_METHOD1(CallStateUpdateControl, void(IAPCommunicationsCallState item));
//     MOCK_METHOD2(SendCallInformation, void(IAP_CALL_INFO_T *call, IAPCommunicationsCallState item));
//     MOCK_METHOD1(SettingExtraCallCondition, void(IAP_CALL_INFO_T *call));
};

MockCiAP2Telephony * M_CiAP2Telephony;

CiAP2Telephony::CiAP2Telephony(CinemoAutoPtr<ICinemoIAP> &piap, stDeviceFuncParam* pparam) 
{

}

CiAP2Telephony::~CiAP2Telephony() 
{

}

CinemoError CiAP2Telephony::startTelephonyUpdate() 
{
    return M_CiAP2Telephony->startTelephonyUpdate();
}

CinemoError CiAP2Telephony::stopTelephonyUpdate() 
{
    return M_CiAP2Telephony->stopTelephonyUpdate();
}

CinemoError CiAP2Telephony::AcceptCallImpl() 
{
    return M_CiAP2Telephony->AcceptCallImpl();
}

CinemoError CiAP2Telephony::EndCallImpl() 
{
    return M_CiAP2Telephony->EndCallImpl();
}

void CiAP2Telephony::RegisterTelephonyCallbk(CBFUNC_iAP2 func, void* ctx) 
{
//    M_CiAP2Telephony->RegisterTelephonyCallbk(func, ctx);
}

CinemoError CiAP2Telephony::AcceptNewCallImpl(void) 
{
    return M_CiAP2Telephony->AcceptNewCallImpl();
}

CinemoError CiAP2Telephony::EndNewCallImpl(void) 
{
    return M_CiAP2Telephony->EndNewCallImpl();
}

CinemoError CiAP2Telephony::IgonrCallImpl(void) 
{
    return M_CiAP2Telephony->IgonrCallImpl();
}

CinemoError CiAP2Telephony::InitiateCallImpl(IAP_RECENTS_ITEM_ELEMENT_T item) 
{
    return M_CiAP2Telephony->InitiateCallImpl(item);
}

CinemoError CiAP2Telephony::SwapCallsImpl() 
{
    return M_CiAP2Telephony->SwapCallsImpl();
}

CinemoError CiAP2Telephony::MergeCallsImpl() 
{
    return M_CiAP2Telephony->MergeCallsImpl();
}

CinemoError CiAP2Telephony::MuteStatusUpdateImpl(bool muteStatus) 
{
    return M_CiAP2Telephony->MuteStatusUpdateImpl(muteStatus);
}

int CiAP2Telephony::SearchFocusCallPosition() 
{
    return M_CiAP2Telephony->SearchFocusCallPosition();
}

CinemoError CiAP2Telephony::CallStateUpdate(const CinemoIAPCommunicationsCallState& update) 
{
    return M_CiAP2Telephony->CallStateUpdate(update);
}

CinemoError CiAP2Telephony::CommunicationsUpdate(const CinemoIAPCommunicationsUpdate& update) 
{
    return M_CiAP2Telephony->CommunicationsUpdate(update);
}

CinemoError CiAP2Telephony::ListUpdate(const CinemoIAPCommunicationsListUpdate& update) 
{
    return M_CiAP2Telephony->ListUpdate(update);
}

const char* CiAP2Telephony::CallStatusToString(E_CALL_STATUS_T status) 
{
    return M_CiAP2Telephony->CallStatusToString(status);
}

const char* CiAP2Telephony::CallDirectionToString(E_CALL_DIRECTION_T direction) 
{
    return M_CiAP2Telephony->CallDirectionToString(direction);
}

void CiAP2Telephony::ParseUtf8String(char* outStr, const char* inStr, size_t length) 
{
//    M_CiAP2Telephony->ParseUtf8String(outStr, inStr, length);
}

void CiAP2Telephony::CallStateUpdateControl(IAPCommunicationsCallState item) 
{
//    M_CiAP2Telephony->CallStateUpdateControl(item);
}

void CiAP2Telephony::SendCallInformation(IAP_CALL_INFO_T *call, IAPCommunicationsCallState item) 
{
//    M_CiAP2Telephony->SendCallInformation(call, item);
}

void CiAP2Telephony::SettingExtraCallCondition(IAP_CALL_INFO_T *call) 
{
//    M_CiAP2Telephony->SettingExtraCallCondition(call);
}


