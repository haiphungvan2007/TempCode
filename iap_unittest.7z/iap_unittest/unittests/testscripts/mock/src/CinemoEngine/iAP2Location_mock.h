class MockCiAP2Location {
  public:
    MOCK_METHOD0(SendLocationInfo, CinemoError());
    MOCK_METHOD0(StopLocationInformation, CinemoError());
    MOCK_METHOD1(StartLocationInformation, CinemoError(const int message_flags));
    MOCK_METHOD1(GPRMCDataStatusValuesNotification, CinemoError(const int message_flags));
//     MOCK_METHOD0(CheckVaildLocationData, void());
    MOCK_METHOD0(CheckVaildLocationData, CinemoError());
    MOCK_METHOD0(SendLocationMessage, CinemoError());
//     MOCK_METHOD1(CalcUtcOffsetTime, void(struct timespec* tv));
    MOCK_METHOD2(DegreeToDMS, double(float inPos, bool* outPosFlag));
    MOCK_METHOD1(DMSToDegree, double(float inPos));
    MOCK_METHOD5(WriteGPGGA, CinemoError(ICinemoUTF8* szgga, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp, char gps_quality));
    MOCK_METHOD4(WriteGPGGA, CinemoError(ICinemoUTF8* szgga, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp));
    MOCK_METHOD4(WriteGPRMC, CinemoError(ICinemoUTF8* szrmc, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp));
//     MOCK_METHOD3(WritePASCD, void(ICinemoUTF8 * szscd, const int& inGear, const float& inSpeed));
    MOCK_METHOD2(GetTimestamp, bool(struct tm* pGmt, struct timespec* pTp));
    MOCK_METHOD1(CalCheckSum, char(const char* data));
};

MockCiAP2Location * M_CiAP2Location;

CiAP2Location::CiAP2Location(CinemoAutoPtr<ICinemoIAP> &piap, stDeviceFuncParam_t* pparam, iAP2InternalFuncState* pInternalFuncState) 
{

}

CiAP2Location::~CiAP2Location() 
{

}

CinemoError CiAP2Location::SendLocationInfo() 
{
    return M_CiAP2Location->SendLocationInfo();
}

CinemoError CiAP2Location::StopLocationInformation() 
{
    return M_CiAP2Location->StopLocationInformation();
}

CinemoError CiAP2Location::StartLocationInformation(const int message_flags) 
{
    return M_CiAP2Location->StartLocationInformation(message_flags);
}

CinemoError CiAP2Location::GPRMCDataStatusValuesNotification(const int message_flags) 
{
    return M_CiAP2Location->GPRMCDataStatusValuesNotification(message_flags);
}

void CiAP2Location::CheckVaildLocationData() 
{
//    M_CiAP2Location->CheckVaildLocationData();
}

CinemoError CiAP2Location::CheckVaildLocationData() 
{
    return M_CiAP2Location->CheckVaildLocationData();
}

CinemoError CiAP2Location::SendLocationMessage() 
{
    return M_CiAP2Location->SendLocationMessage();
}

void CiAP2Location::CalcUtcOffsetTime(struct timespec* tv) 
{
//    M_CiAP2Location->CalcUtcOffsetTime(tv);
}

double CiAP2Location::DegreeToDMS(float inPos, bool* outPosFlag) 
{
    return M_CiAP2Location->DegreeToDMS(inPos, outPosFlag);
}

double CiAP2Location::DMSToDegree(float inPos) 
{
    return M_CiAP2Location->DMSToDegree(inPos);
}

CinemoError CiAP2Location::WriteGPGGA(ICinemoUTF8* szgga, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp, char gps_quality) 
{
    return M_CiAP2Location->WriteGPGGA(szgga, locInfo, pGmt, pTp, gps_quality);
}

CinemoError CiAP2Location::WriteGPGGA(ICinemoUTF8* szgga, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp) 
{
    return M_CiAP2Location->WriteGPGGA(szgga, locInfo, pGmt, pTp);
}

CinemoError CiAP2Location::WriteGPRMC(ICinemoUTF8* szrmc, const CARPLAY_LOCATION_INFO_T& locInfo, struct tm* pGmt, struct timespec* pTp) 
{
    return M_CiAP2Location->WriteGPRMC(szrmc, locInfo, pGmt, pTp);
}

void CiAP2Location::WritePASCD(ICinemoUTF8 * szscd, const int& inGear, const float& inSpeed) 
{
//    M_CiAP2Location->WritePASCD(szscd, inGear, inSpeed);
}

bool CiAP2Location::GetTimestamp(struct tm* pGmt, struct timespec* pTp) 
{
    return M_CiAP2Location->GetTimestamp(pGmt, pTp);
}

char CiAP2Location::CalCheckSum(const char* data) 
{
    return M_CiAP2Location->CalCheckSum(data);
}


