class MockCiAP2Vehicle {
  public:
    MOCK_METHOD0(SendVehicleStatus, CinemoError());
    MOCK_METHOD0(StopVehicleStatus, CinemoError());
//     MOCK_METHOD2(AddiAP2VehicleStatusCallbk, void(CBFUNC_iAP2 func, void * ctx));
//     MOCK_METHOD1(IAP2VehMutexLock, void(bool bEnable));
//     MOCK_METHOD0(IAP2VehCondSignal, void());
    MOCK_METHOD1(StartVehicleStatus, CinemoError(const CinemoIAPVehicleStatus& status));
    MOCK_METHOD0(SetAccessoryVehicleState, bool());
};

MockCiAP2Vehicle * M_CiAP2Vehicle;

CiAP2Vehicle::CiAP2Vehicle(CinemoAutoPtr<ICinemoIAP> &piap, stDeviceFuncParam* pparam, iAP2InternalFuncState* pInternalFuncState) 
{

}

CiAP2Vehicle::~CiAP2Vehicle() 
{

}

CinemoError CiAP2Vehicle::SendVehicleStatus() 
{
    return M_CiAP2Vehicle->SendVehicleStatus();
}

CinemoError CiAP2Vehicle::StopVehicleStatus() 
{
    return M_CiAP2Vehicle->StopVehicleStatus();
}

void CiAP2Vehicle::AddiAP2VehicleStatusCallbk(CBFUNC_iAP2 func, void * ctx) 
{
//    M_CiAP2Vehicle->AddiAP2VehicleStatusCallbk(func, ctx);
}

void CiAP2Vehicle::IAP2VehMutexLock(bool bEnable) 
{
//    M_CiAP2Vehicle->IAP2VehMutexLock(bEnable);
}

void CiAP2Vehicle::IAP2VehCondSignal() 
{
//    M_CiAP2Vehicle->IAP2VehCondSignal();
}

CinemoError CiAP2Vehicle::StartVehicleStatus(const CinemoIAPVehicleStatus& status) 
{
    return M_CiAP2Vehicle->StartVehicleStatus(status);
}

bool CiAP2Vehicle::SetAccessoryVehicleState() 
{
    return M_CiAP2Vehicle->SetAccessoryVehicleState();
}


