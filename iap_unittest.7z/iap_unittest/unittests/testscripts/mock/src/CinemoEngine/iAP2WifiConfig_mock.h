class MockCiAP2WifiConfig {
  public:
    MOCK_METHOD1(WiFiInformation, CinemoError(const CinemoIAPWiFiInfo& info));
    MOCK_METHOD0(RequestAccessoryWiFiConfigurationInformation, CinemoError());
//     MOCK_METHOD1(SetWifiCredential, void(WIFI_CREDENTIAL_INFO* wifi_info));
};

MockCiAP2WifiConfig * M_CiAP2WifiConfig;

CiAP2WifiConfig::CiAP2WifiConfig(CinemoAutoPtr<ICinemoIAP> &piap) 
{

}

CiAP2WifiConfig::~CiAP2WifiConfig() 
{

}

CinemoError CiAP2WifiConfig::WiFiInformation(const CinemoIAPWiFiInfo& info) 
{
    return M_CiAP2WifiConfig->WiFiInformation(info);
}

CinemoError CiAP2WifiConfig::RequestAccessoryWiFiConfigurationInformation() 
{
    return M_CiAP2WifiConfig->RequestAccessoryWiFiConfigurationInformation();
}

void CiAP2WifiConfig::SetWifiCredential(WIFI_CREDENTIAL_INFO* wifi_info) 
{
//    M_CiAP2WifiConfig->SetWifiCredential(wifi_info);
}


