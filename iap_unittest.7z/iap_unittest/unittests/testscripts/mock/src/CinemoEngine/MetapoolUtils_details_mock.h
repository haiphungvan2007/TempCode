namespace CINEMO_SUPPORT {
namespace details {

class Mockpex<uint8> {
  public:
};

Mockpex<uint8> * M_pex<uint8>;

class Mockpex<uint16> {
  public:
};

Mockpex<uint16> * M_pex<uint16>;

class Mockpex<uint32> {
  public:
};

Mockpex<uint32> * M_pex<uint32>;

class Mockpex<uint64> {
  public:
};

Mockpex<uint64> * M_pex<uint64>;

}  // namespace details
}  // namespace CINEMO_SUPPORT

