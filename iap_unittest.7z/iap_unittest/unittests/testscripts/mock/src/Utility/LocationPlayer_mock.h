class MockLocationPlayer {
};

MockLocationPlayer * M_LocationPlayer;

