class MockCIapCommon {
  public:
//     MOCK_METHOD0(MAKE_SINGLETON, void(CIapCommon));
//     MOCK_METHOD5(SendMessageImpl, void(ProcId , short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrTskImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrSysImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToAppMainImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrMyMediaImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrIpodImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrBootImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrFavImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrBtImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrConnImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrCarPlayImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrCarLifeImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrAAImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrVipImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrVidImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrMcmImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrLogImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrOnstarImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToAgentImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrWifiImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrIapImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD4(SendToMgrClusterImpl, void(short , void *, size_t , MqPriority ));
//     MOCK_METHOD5(SendToOtherProcImpl, void(ProcId , short , void *, size_t , MqPriority ));
};

MockCIapCommon * M_CIapCommon;

void CIapCommon::MAKE_SINGLETON(CIapCommon) 
{
//    M_CIapCommon->MAKE_SINGLETON(CIapCommon);
}

void CIapCommon::SendMessageImpl(ProcId ProcID, short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendMessageImpl(ProcID, usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrTskImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrTskImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrSysImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrSysImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToAppMainImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToAppMainImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrMyMediaImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrMyMediaImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrIpodImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrIpodImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrBootImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrBootImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrFavImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrFavImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrBtImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrBtImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrConnImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrConnImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrCarPlayImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrCarPlayImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrCarLifeImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrCarLifeImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrAAImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrAAImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrVipImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrVipImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrVidImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrVidImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrMcmImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrMcmImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrLogImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrLogImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrOnstarImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrOnstarImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToAgentImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToAgentImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrWifiImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrWifiImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrIapImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrIapImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToMgrClusterImpl(short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToMgrClusterImpl(usFnc, pExtra, iSizeExtra, ePriority);
}

void CIapCommon::SendToOtherProcImpl(ProcId ProcID, short usFnc, void *pExtra, size_t iSizeExtra, MqPriority ePriority) 
{
//    M_CIapCommon->SendToOtherProcImpl(ProcID, usFnc, pExtra, iSizeExtra, ePriority);
}


