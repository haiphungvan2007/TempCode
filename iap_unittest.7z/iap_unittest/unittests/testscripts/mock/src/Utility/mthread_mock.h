class MockMThread {
  public:
    MOCK_METHOD1(start, MThreadError(const char* pName));
    MOCK_METHOD0(detach, MThreadError());
    MOCK_METHOD0(join, MThreadError());
    MOCK_METHOD0(cancel, MThreadError());
    MOCK_METHOD0(isRunning, bool());
    MOCK_METHOD0(self, pthread_t());
    MOCK_METHOD1(set_priority, int(const int& priority));
//     MOCK_METHOD0(run, void());
};

MockMThread * M_MThread;

MThread::MThread() 
{

}

MThread::~MThread() 
{

}

MThreadError MThread::start(const char* pName) 
{
    return M_MThread->start(pName);
}

MThreadError MThread::detach() 
{
    return M_MThread->detach();
}

MThreadError MThread::join() 
{
    return M_MThread->join();
}

MThreadError MThread::cancel() 
{
    return M_MThread->cancel();
}

bool MThread::isRunning() 
{
    return M_MThread->isRunning();
}

pthread_t MThread::self() 
{
    return M_MThread->self();
}

int MThread::set_priority(const int& priority) 
{
    return M_MThread->set_priority(priority);
}

void MThread::run() 
{
//    M_MThread->run();
}

MThread::MThread(const MThread&) 
{

}


