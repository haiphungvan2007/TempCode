class MockCIapMutex {
};

MockCIapMutex * M_CIapMutex;

class MockCIapCondVar {
  public:
};

MockCIapCondVar * M_CIapCondVar;

CIapCondVar::CIapCondVar() 
{

}


