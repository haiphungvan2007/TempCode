class MockCMgrIap {
  public:
//     MOCK_METHOD1(ConnectDevice, void(const void* data));
//     MOCK_METHOD1(DisconnectDevice, void(const void* data));
//     MOCK_METHOD1(SetConsent, void(const void* data));
//     MOCK_METHOD1(RequestBtWCP, void(const void* pdata));
//     MOCK_METHOD1(SwitchTransportToUSB, void(const void* pdata));
//     MOCK_METHOD1(RequestProjection, void(const void* pdata));
//     MOCK_METHOD1(RequestRoleSwapManually, void(const void* data));
//     MOCK_METHOD1(SetSettingCarLife, void(const void* data));
//     MOCK_METHOD1(SetSettingCarPlay, void(const void* data));
//     MOCK_METHOD1(SetSettingWirelessCarPlay, void(const void* bdata));
//     MOCK_METHOD2(SetHardwareVersion, void(const void* data, size_t size));
//     MOCK_METHOD2(SetSerialNumber, void(const void* data, size_t size));
//     MOCK_METHOD1(SetLocationStatus, void(const void* data));
//     MOCK_METHOD1(ConnectWireless, void(const void* data));
//     MOCK_METHOD1(DisconnectWireless, void(const void* data));
     MOCK_METHOD0(AcceptCarPlayCall, void());
//     MOCK_METHOD0(RejectCarPlayCall, void());
//     MOCK_METHOD0(LoadCalibration, void());
//     MOCK_METHOD1(SetBtLocalInfo, void(const void* data));
//     MOCK_METHOD1(SendOOBBTPairingCompletionInfo, void(const void* pdata));
//     MOCK_METHOD1(ConnectBt, void(const void* data));
//     MOCK_METHOD1(CheckBtUUID, void(const void* data));
//     MOCK_METHOD1(CheckDeviceUUID, void(const void* usbDevInfo));
//     MOCK_METHOD1(ReleaseIapDeviceImpl, void(const void* pdata));
//     MOCK_METHOD1(SetRuntimeLocation, void(const void* wired));
//     MOCK_METHOD1(SetWifiInfo, void(const void* pdata));
//     MOCK_METHOD1(SetCinemoLog, void(const void* data));
//     MOCK_METHOD2(SetLanguage, void(const void* data, size_t size));
//     MOCK_METHOD1(SetIsReLaunched, void(bool relaunch));
//     MOCK_METHOD0(SetAccessoryInformation, void(void));
     MOCK_METHOD2(AcceptNewCarPlayCall, void(const void* data, size_t size));
//     MOCK_METHOD2(RejectNewCarPlayCall, void(const void* data, size_t size));
//     MOCK_METHOD2(IgnorCarPlayCall, void(const void* data, size_t size));
//     MOCK_METHOD0(SwapCarPlayCall, void());
//     MOCK_METHOD0(MergeCarPlayCall, void());
//     MOCK_METHOD2(MuteStatusCarPlayUpdate, void(const void* data, size_t size));
//     MOCK_METHOD2(RecentCallHistory, void(const void* data, size_t size));
//     MOCK_METHOD2(RecentCallDial, void(const void* data, size_t size));
//     MOCK_METHOD0(SendCarPlayCallTimer, void());
    MOCK_METHOD2(RequestRoleSwap, bool(const E_IAP_TYPE_T type, stUsbDevInfo_t* pDevInfo));
//     MOCK_METHOD1(ConnectIpod, void(stSessionInfo_t* pSessionInfo));
//     MOCK_METHOD1(DisconnectIpod, void(stUsbDevInfo_t* pDevInfo));
//     MOCK_METHOD1(ConnectCarPlay, void(stSessionInfo_t* pSessionInfo));
//     MOCK_METHOD0(DisconnectCarPlay, void());
//     MOCK_METHOD1(ConnectCarLife, void(stSessionInfo_t* pSessionInfo));
//     MOCK_METHOD0(DisconnectCarLife, void());
//     MOCK_METHOD2(ConnectBtWCP, void(stSessionInfo_t* pSessionInfo, const bool sessionStatus));
//     MOCK_METHOD2(RemoveBtWCP, void(void *, bool ));
//     MOCK_METHOD1(RemoveBtDevice, void(const char* btDevName));
//     MOCK_METHOD1(InitIapConf, void(IAP_CONF_T* pConf));
//     MOCK_METHOD0(SetFirmwareVerImpl, void());
//     MOCK_METHOD1(ReleaseIap, void(const char* strDevName));
//     MOCK_METHOD0(SendSessionStatus, void());
};

MockCMgrIap * M_CMgrIap;

CMgrIap::CMgrIap() 
{

}

CMgrIap::~CMgrIap() 
{

}

void CMgrIap::ConnectDevice(const void* data) 
{
//    M_CMgrIap->ConnectDevice(data);
}

void CMgrIap::DisconnectDevice(const void* data) 
{
//    M_CMgrIap->DisconnectDevice(data);
}

void CMgrIap::SetConsent(const void* data) 
{
//    M_CMgrIap->SetConsent(data);
}

void CMgrIap::RequestBtWCP(const void* pdata) 
{
//    M_CMgrIap->RequestBtWCP(pdata);
}

void CMgrIap::SwitchTransportToUSB(const void* pdata) 
{
//    M_CMgrIap->SwitchTransportToUSB(pdata);
}

void CMgrIap::RequestProjection(const void* pdata) 
{
//    M_CMgrIap->RequestProjection(pdata);
}

void CMgrIap::RequestRoleSwapManually(const void* data) 
{
//    M_CMgrIap->RequestRoleSwapManually(data);
}

void CMgrIap::SetSettingCarLife(const void* data) 
{
//    M_CMgrIap->SetSettingCarLife(data);
}

void CMgrIap::SetSettingCarPlay(const void* data) 
{
//    M_CMgrIap->SetSettingCarPlay(data);
}

void CMgrIap::SetSettingWirelessCarPlay(const void* bdata) 
{
//    M_CMgrIap->SetSettingWirelessCarPlay(bdata);
}

void CMgrIap::SetHardwareVersion(const void* data, size_t size) 
{
//    M_CMgrIap->SetHardwareVersion(data, size);
}

void CMgrIap::SetSerialNumber(const void* data, size_t size) 
{
//    M_CMgrIap->SetSerialNumber(data, size);
}

void CMgrIap::SetLocationStatus(const void* data) 
{
//    M_CMgrIap->SetLocationStatus(data);
}

void CMgrIap::ConnectWireless(const void* data) 
{
//    M_CMgrIap->ConnectWireless(data);
}

void CMgrIap::DisconnectWireless(const void* data) 
{
//    M_CMgrIap->DisconnectWireless(data);
}

void CMgrIap::AcceptCarPlayCall() 
{
    M_CMgrIap->AcceptCarPlayCall();
}

void CMgrIap::RejectCarPlayCall() 
{
//    M_CMgrIap->RejectCarPlayCall();
}

void CMgrIap::LoadCalibration() 
{
//    M_CMgrIap->LoadCalibration();
}

void CMgrIap::SetBtLocalInfo(const void* data) 
{
//    M_CMgrIap->SetBtLocalInfo(data);
}

void CMgrIap::SendOOBBTPairingCompletionInfo(const void* pdata) 
{
//    M_CMgrIap->SendOOBBTPairingCompletionInfo(pdata);
}

void CMgrIap::ConnectBt(const void* data) 
{
//    M_CMgrIap->ConnectBt(data);
}

void CMgrIap::CheckBtUUID(const void* data) 
{
//    M_CMgrIap->CheckBtUUID(data);
}

void CMgrIap::CheckDeviceUUID(const void* usbDevInfo) 
{
//    M_CMgrIap->CheckDeviceUUID(usbDevInfo);
}

void CMgrIap::ReleaseIapDeviceImpl(const void* pdata) 
{
//    M_CMgrIap->ReleaseIapDeviceImpl(pdata);
}

void CMgrIap::SetRuntimeLocation(const void* wired) 
{
//    M_CMgrIap->SetRuntimeLocation(wired);
}

void CMgrIap::SetWifiInfo(const void* pdata) 
{
//    M_CMgrIap->SetWifiInfo(pdata);
}

void CMgrIap::SetCinemoLog(const void* data) 
{
//    M_CMgrIap->SetCinemoLog(data);
}

void CMgrIap::SetLanguage(const void* data, size_t size) 
{
//    M_CMgrIap->SetLanguage(data, size);
}

void CMgrIap::SetIsReLaunched(bool relaunch) 
{
//    M_CMgrIap->SetIsReLaunched(relaunch);
}

void CMgrIap::SetAccessoryInformation(void) 
{
//    M_CMgrIap->SetAccessoryInformation();
}

void CMgrIap::AcceptNewCarPlayCall(const void* data, size_t size) 
{
    M_CMgrIap->AcceptNewCarPlayCall(data, size);
}

void CMgrIap::RejectNewCarPlayCall(const void* data, size_t size) 
{
//    M_CMgrIap->RejectNewCarPlayCall(data, size);
}

void CMgrIap::IgnorCarPlayCall(const void* data, size_t size) 
{
//    M_CMgrIap->IgnorCarPlayCall(data, size);
}

void CMgrIap::SwapCarPlayCall() 
{
//    M_CMgrIap->SwapCarPlayCall();
}

void CMgrIap::MergeCarPlayCall() 
{
//    M_CMgrIap->MergeCarPlayCall();
}

void CMgrIap::MuteStatusCarPlayUpdate(const void* data, size_t size) 
{
//    M_CMgrIap->MuteStatusCarPlayUpdate(data, size);
}

void CMgrIap::RecentCallHistory(const void* data, size_t size) 
{
//    M_CMgrIap->RecentCallHistory(data, size);
}

void CMgrIap::RecentCallDial(const void* data, size_t size) 
{
//    M_CMgrIap->RecentCallDial(data, size);
}

void CMgrIap::SendCarPlayCallTimer() 
{
//    M_CMgrIap->SendCarPlayCallTimer();
}

bool CMgrIap::RequestRoleSwap(const E_IAP_TYPE_T type, stUsbDevInfo_t* pDevInfo) 
{
    return M_CMgrIap->RequestRoleSwap(type, pDevInfo);
}

void CMgrIap::ConnectIpod(stSessionInfo_t* pSessionInfo) 
{
//    M_CMgrIap->ConnectIpod(pSessionInfo);
}

void CMgrIap::DisconnectIpod(stUsbDevInfo_t* pDevInfo) 
{
//    M_CMgrIap->DisconnectIpod(pDevInfo);
}

void CMgrIap::ConnectCarPlay(stSessionInfo_t* pSessionInfo) 
{
//    M_CMgrIap->ConnectCarPlay(pSessionInfo);
}

void CMgrIap::DisconnectCarPlay() 
{
//    M_CMgrIap->DisconnectCarPlay();
}

void CMgrIap::ConnectCarLife(stSessionInfo_t* pSessionInfo) 
{
//    M_CMgrIap->ConnectCarLife(pSessionInfo);
}

void CMgrIap::DisconnectCarLife() 
{
//    M_CMgrIap->DisconnectCarLife();
}

void CMgrIap::ConnectBtWCP(stSessionInfo_t* pSessionInfo, const bool sessionStatus) 
{
//    M_CMgrIap->ConnectBtWCP(pSessionInfo, sessionStatus);
}

//void CMgrIap::RemoveBtWCP(void *data, bool bRequestCancel)
//{
////    M_CMgrIap->RemoveBtWCP();
//}

void CMgrIap::RemoveBtDevice(const char* btDevName) 
{
//    M_CMgrIap->RemoveBtDevice(btDevName);
}

void CMgrIap::InitIapConf(IAP_CONF_T* pConf) 
{
//    M_CMgrIap->InitIapConf(pConf);
}

void CMgrIap::SetFirmwareVerImpl() 
{
//    M_CMgrIap->SetFirmwareVerImpl();
}

void CMgrIap::ReleaseIap(const char* strDevName) 
{
//    M_CMgrIap->ReleaseIap(strDevName);
}

void CMgrIap::SendSessionStatus() 
{
//    M_CMgrIap->SendSessionStatus();
}


