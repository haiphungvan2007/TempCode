class MockCCalibration {
  public:
//     MOCK_METHOD0(Load, void());
    MOCK_METHOD1(get_country_group, uint8_t(const uint8_t country_code));
    MOCK_METHOD1(select_channelArrange, uint8_t(uint8_t countrycode));
//     MOCK_METHOD0(BrandCode, void());
//     MOCK_METHOD0(CountryCode, void());
//     MOCK_METHOD0(SupportedLanguages, void());
//     MOCK_METHOD0(CarPlaySetting, void());
//     MOCK_METHOD0(LocationEnable, void());
//     MOCK_METHOD0(AccessVehicleDataEnable, void());
//     MOCK_METHOD0(WirelessEnable, void());
//     MOCK_METHOD0(readOnStarSvcOn, void());
};

MockCCalibration * M_CCalibration;

CCalibration::CCalibration() 
{

}

CCalibration::~CCalibration() 
{

}

void CCalibration::Load() 
{
//    M_CCalibration->Load();
}

uint8_t CCalibration::get_country_group(const uint8_t country_code) 
{
    return M_CCalibration->get_country_group(country_code);
}

uint8_t CCalibration::select_channelArrange(uint8_t countrycode) 
{
    return M_CCalibration->select_channelArrange(countrycode);
}

void CCalibration::BrandCode() 
{
//    M_CCalibration->BrandCode();
}

void CCalibration::CountryCode() 
{
//    M_CCalibration->CountryCode();
}

void CCalibration::SupportedLanguages() 
{
//    M_CCalibration->SupportedLanguages();
}

void CCalibration::CarPlaySetting() 
{
//    M_CCalibration->CarPlaySetting();
}

void CCalibration::LocationEnable() 
{
//    M_CCalibration->LocationEnable();
}

void CCalibration::AccessVehicleDataEnable() 
{
//    M_CCalibration->AccessVehicleDataEnable();
}

void CCalibration::WirelessEnable() 
{
//    M_CCalibration->WirelessEnable();
}

void CCalibration::readOnStarSvcOn() 
{
//    M_CCalibration->readOnStarSvcOn();
}


