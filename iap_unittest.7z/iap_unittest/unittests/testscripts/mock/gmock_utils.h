/*
 * utils.h
 *
 *  Created on: Feb 16, 2020
 *      Author: hung.ho
 */

#ifndef _GMOCK_UTILS_H_
#define _GMOCK_UTILS_H_

#include "gmock/gmock.h"

#define EXPECT_ARRAY_EQ(ar1, ar2, count)	\
	for(unsigned int i = 0; i<count;i++)							\
	{													\
		EXPECT_EQ(ar1[i],ar2[i]) << "EXPECT_ARRAY_EQ Failed at index = " <<i;	\
	}													\

#define ASSERT_ARRAY_EQ(ar1, ar2, count)	\
	for(unsigned int i = 0; i<count;i++)							\
	{													\
		ASSERT_EQ(ar1[i],ar2[i]) << "ASSERT_ARRAY_EQ Failed at index = " <<i;	\
	}


#endif /* _GMOCK_UTILS_H_ */
