/**********************************************
 *********   UTS VERSION : 1.5.0-a2    *********
 **********************************************/


#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <dlfcn.h>

// Include Source File for testing!!

#include "../CinemoEngine/ErrorReport.cpp"
using namespace CINEMO_SUPPORT;

// Include MOCK FILES!!
//#include "mock/src/CMgrIap_mock.h"

/*
 * Define Mock/Mock function
 */
class BaseErrorReport {
public:
    virtual ~BaseErrorReport(){  }
};

class MockErrorReport : public BaseErrorReport {
public:
};

MockErrorReport *M_ErrorReport;

using ::testing::Return;
using ::testing::_;
using ::testing::A;
using ::testing::ReturnRef;
using ::testing::Values;
using ::testing::SetArgPointee;
using ::testing::SetArrayArgument;
using ::testing::SaveArg;
using ::testing::SaveArgPointee;
using ::testing::DoAll;
using ::testing::Args;
using ::testing::AllOf;
using ::testing::AtLeast;
using ::testing::Combine;
using ::testing::InSequence;
class ErrorReportTest : public ::testing::Test {
protected:
    virtual void SetUp() {
        testObj = new ThrowingErrorReporter;

    }
    virtual void TearDown() {

       delete testObj;
    }
    ThrowingErrorReporter* testObj;
};

/**
*   @brief This is a test script for the Error function of class ThrowingErrorReporter
*   @classID ThrowingErrorReporter
*   @methodID ThrowingErrorReporter_Error
*   @paramList CinemoError errorID,
*   @priority P2
*   @resolution_Method Equivalence Partitioning
*   @test_condition errorID in range from CinemoNoError to CinemoErrorTLSShutdownFailed
*   @test_Coverage_Item errorID in range from CinemoNoError to CinemoErrorTLSShutdownFailed
*   @test_case_ID ThrowingErrorReporter_Error_TC001
*   @test_type functionality
*   @test_objective testing function with input error CinemoNoError
*   @test_precon N/A
*   @test_input errorID = CinemoNoError, errorMessage = "CinemoNoError"
*   @test_expected_result isThrowException = FALSE (No exception will be thrown)
*   @test_module CinemoEngine
*   @design_id N/A
*/
TEST_F(ErrorReportTest, ThrowingErrorReporter_Error_TC001)
{
	//Input value
	CinemoError errorID = CinemoNoError;
	const char* errorMessage = "CinemoNoError";

	//Expected result
	bool expectedResult = false;

	//Actual result
	bool isThrowException = false;

	try {
		testObj->Error(errorID, errorMessage);
	} catch (const char* error) {
		isThrowException = true;
	}

	EXPECT_EQ(expectedResult, isThrowException);
}

/**
*   @brief This is a test script for the Error function of class ThrowingErrorReporter
*   @classID ThrowingErrorReporter
*   @methodID ThrowingErrorReporter_Error
*   @paramList CinemoError errorID,
*   @priority P2
*   @resolution_Method Equivalence Partitioning
*   @test_condition errorID in range from CinemoNoError to CinemoErrorTLSShutdownFailed
*   @test_Coverage_Item errorID in range from CinemoNoError to CinemoErrorTLSShutdownFailed
*   @test_case_ID ThrowingErrorReporter_Error_TC002
*   @test_type functionality
*   @test_objective testing function with input error CinemoErrorTLSShutdownFailed
*   @test_precon N/A
*   @test_input errorID = CinemoErrorTLSShutdownFailed, errorMessage = "CinemoErrorTLSShutdownFailed"
*   @test_expected_result isThrowException = TRUE (An exception will be thrown)
*   @test_module CinemoEngine
*   @design_id N/A
*/
TEST_F(ErrorReportTest, ThrowingErrorReporter_Error_TC002)
{
	//Input value
		CinemoError errorID = CinemoErrorTLSShutdownFailed;
		const char* errorMessage = "CinemoErrorTLSShutdownFailed";

		//Expected result
		bool expectedResult = true;

		//Actual result
		bool isThrowException = false;

		try {
			testObj->Error(errorID, errorMessage);
		} catch (const char* error) {
			isThrowException = true;
		}

		EXPECT_EQ(expectedResult, isThrowException);
}
